#' This functions computes the day number since january first of the repsective year
#' @param date
#' @return juliaday
#' @examples
fx.julian.day<-function(x=as.Date("2005-01-31")){
  yr<-as.numeric(format(x,'%Y'))
  origin<-as.Date(paste0(yr,"-01-01"))
  jdate<-as.numeric(x-origin+1) #julian(x,origin = origin)+1 #days since 1970-01-01
  return(jdate)
}

#' This functions computes the hydrological year for a date given the month number in which the hydrological year starts
#' The water year is designated by the calendar year in which it ends,
#' so ifthe 2024 water year started on september 1, 2023, it will end on August 30, 2024
#' @param date
#' @return juliaday
#' @examples
fx.hydrological.year<-function(x=as.Date("2005-01-31"),month=9){
  yr<-as.numeric(format(x,'%Y'))
  mo<-as.numeric(format(x,'%m'))
  hyear<-apply(data.frame(mo,yr),1,function(x) {if(x[1]>=month){return(x[2]+1)} else {return(x[2])}})
  return(hyear)
}

#' volumetric efficiency
#' The VE represents the fractional volumetric difference between the simulated
#' and observed streamflows. It ranges from 0 to 1.
#' A perfect value of 1 indicates that the volume of water
#' predicted by the model matches the observed volume.
#' This criterion gives the same weight to any flow range
#' (e.g., slow recession and rapid rising flow),
#' relaxing the constraint of model residuals heteroscedasticity
#' references
#' https://hess.copernicus.org/articles/26/197/2022/hess-26-197-2022-supplement.pdf
#' https://www.scielo.br/j/rbrh/a/RhjqdXxzfkPH79GpQS9VjWd/?lang=en&format=pdf
#' @import zoo
#' @param Qsim
#' @param Qobs
#' @return KGE
#' @examples
fx.ve<-function(Qsim,Qobs){  #calc
  qna<-data.frame(Qsim,Qobs)
  q<-qna[!apply(qna,1,function(x) any(is.na(x))),]#remone nas
  VE<-1 - (sum(abs(q$Qsim-q$Qobs))/sum(q$Qobs))
  return(VE)}


#' Nash-Sutcliffe Efficiency (NSE).
#' This functions calculates the Nash-Sutcliffe Efficiency (NSE).
#' NSE = 1 indicates perfect correspondence between simulations and observations
#' NSE = 0 indicates that the model simulations have the same explanatory power as the mean of the observations
#' NSE < 0 indicates that the model is a worse predictor than the mean of the observations
#' #' references
#' https://hess.copernicus.org/articles/26/197/2022/hess-26-197-2022-supplement.pdf
#' https://www.scielo.br/j/rbrh/a/RhjqdXxzfkPH79GpQS9VjWd/?lang=en&format=pdf
#' @import zoo
#' @param Qsim
#' @param Qobs
#' @param with.VE Relative Error  logical. if TRUE calculates NSE*VE
#' @return NSE
#' @examples
fx.nse<-function(Qsim,Qobs,with.VE=FALSE){
  #calc
  qna<-data.frame(Qsim,Qobs)
  q<-qna[!apply(qna,1,function(x) any(is.na(x))),]#remone nas
  nse<-1-sum((q$Qsim-q$Qobs)^2)/ sum((q$Qobs-mean(q$Qobs))^2)

  if(with.VE ==TRUE){
    VE<-fx.ve(Qsim,Qobs)
    nse<-nse*VE
  }
  return(nse)
}

#' Kling-Gupta efficiency scores
#' This functions calculates the Kling-Gupta efficiency scores (KGE).
#' KGE = 1 indicates perfect agreement between simulations and observations. Analogous to NSE = 0,
#' certain authors state that KGE < 0 indicates that the mean of observations provides better estimates than simulations
#' #' references
#' https:#hess.copernicus.org/preprints/hess-2019-327/hess-2019-327.pdf
#' https://hess.copernicus.org/articles/26/197/2022/hess-26-197-2022-supplement.pdf
#' https://www.scielo.br/j/rbrh/a/RhjqdXxzfkPH79GpQS9VjWd/?lang=en&format=pdf
#'
#' @import zoo
#' @param Qsim
#' @param Qobs
#' @return KGE
#' @examples
fx.kge<-function(Qsim,Qobs){
  #calc
  qna<-data.frame(Qsim,Qobs)
  q<-qna[!apply(qna,1,function(x) any(is.na(x))),]#remone nas
  r<-cor(q$Qsim,q$Qobs)#linear correlation between observations and simulation
  AlphA<-sd(q$Qsim)/sd(q$Qobs) #𝛼 a measure of the flow variability error,
  BetA<- mean(q$Qsim)/sd(q$Qobs)  #𝛽 a bias term
  kge <- 1- ((r-1)^2 + (AlphA-1)^2 + (BetA-1)^2)^0.5
  return(kge)
}

#' Plot Timesereies Qobs and Qsim with objective criteria
#' @import zoo
#' @param Qsim
#' @param Qobs
#' @examples
fx.plot.hbv.calib<-function(Qsim=NULL,Qobs=NULL,Time=NULL,las=2){
  # For testing
  # if(is.null(Qsim)){
  #   #synthetic data
  #   Qobs<-runif(100,1,100)
  #   Qsim<-Qobs+runif(100,0,15)
  #   Qobs[unique(ceiling(runif(10,1,100)))]<-NA
  # }

  if(is.null(Time)){
    Time<-1:length(Qobs)
    xp<-1:length(Time)
    xl<-xp
  } else{
    xp<-seq(Time[1],Time[length(Time)]+31,by="month")
    xl<-paste0(as.numeric(format(xp,'%Y')),"-",sprintf("%02d",as.numeric(format(xp,'%m'))))
  }
  qna<-data.frame(Qsim,Qobs)
  yp<-pretty(range(qna,na.rm=TRUE))
  #layout(matrix(1:2,nrow=1,ncol=2),widths=c(5,2))
  #par(mar=c(4,4,1,1),oma=c(1,1,1,1))
  plot(Time,Qobs,type="l",col="blue",
       ylim=c(min(qna,na.rm=TRUE),1.2*max(qna,na.rm=TRUE)),
       ylab="Flow (m³/s)",xlab="Time",las=2,yaxs="i",xaxt="n",yaxt="n")
  VE<-fx.ve(Qsim,Qobs)
  NSE<-fx.nse(Qsim,Qobs,with.VE = F)
  NSE.VE<-fx.nse(Qsim,Qobs,with.VE = T)
  KGE<-fx.kge(Qsim,Qobs)
  obj<-data.frame(NSE=NSE,VE=VE,NSE.VE=NSE.VE,KGE=KGE)
  lines(Time,Qsim,col="red")
  #plot(0, type = 'n', axes = FALSE, ann = FALSE)
  legend("topright",paste(names(obj),"=",round(obj,2)),cex=0.8)
  #par(mar=c(5,4,1,1),oma=c(1,1,1,1))
  #box(which = "outer",col="blue")
  axis(1,xp,xl,las=2,cex.axis=0.8)
  axis(2,yp,yp,las=2,cex.axis=0.8)
  abline(v=xp,lw=0.1,lty=2,col="grey80")
  abline(h=yp,lw=0.1,lty=2,col="grey80")
}


#' This functions reads data from the input files
#' sample files are provided
#' @import zoo
#' @import readxl
#' @import tidyverse
#' @import gdata
#' @param dir
#' @param Timeseries
#' @param Free.txt
#' @param Fixed.txt
#' @param serie.start.date
#' @return hbv data object
#' @examples
fx.hbv.daily.getdata<-function(dir,
                               Timeseries.txt,
                               Free_Par.txt,
                               Fixed_Par.txt,
                               serie.start.date=NULL){
  dir<-"D:/WORK/Tools/R/Packages and Apps/ejjhydrotools/data/hbv/"
  Timeseries.txt=paste0(dir,"/",Timeseries.txt)
  Free.txt=paste0(dir,"/",Free_Par.txt)
  Fixed.txt=paste0(dir,"/",Fixed_Par.txt)


  fri<-read.table(file = Free.txt)
  fxd<-read.table(file = Fixed.txt,nrow=4)
  zone<-read.table(file = Fixed.txt,skip=4,nrow=4)
  timeseries<-read.table(file=Timeseries.txt,header = TRUE)
  if(is.null(serie.start.date)) {serie.start.date=timeseries[1,1]}
  timeseries$Date<-seq(as.Date(serie.start.date),as.Date(serie.start.date)+ nrow(timeseries)-1,1)
  timeseries$jdate<-fx.julian.day(timeseries$Date)
  timeseries$hyear<-fx.hydrological.year(timeseries$Date,month=9)

  input<-list(files=list(dir = dir,
                        Fixed.txt = Fixed.txt,
                        Free.txt = Free.txt,
                        Timeseries.txt = Timeseries.txt),
             data=list(fri = fri,
                       fxd = fxd,
                       zones = zone,
                       serie.start.date = serie.start.date,
                       timeseries = timeseries,
                       hyear=unique(timeseries$hyear))
  )
  return(input)

}

#' This is the hbv model for the given parameters and entire dataset
#' @import zoo
#' @import dplyr
#' @import readxl
#' @import tidyverse
#' @import gdata
#' @param prm free-parameters
#' @param input inputdata from fx.hbv.daily.getdata()
#' @param Snow2GlacierOption TRUE, convert snow to glacier at end of hydrological year
#' @param Snow2GlacierJulianDate  as.Date("2000-09-01"), Date for calc of Snow2GlacierJulianday.
#' @param calibrate Makes the function return obj.crit if TRUE to enable optimisation
#' @param obj.criteria Choose an optmising objective criteria from ("NSE","VE","NSE.VE","KGE")
#' @param icall controls printing of visual obj.criteria during calibration if provided by external calib function
#' @return either objective critria or results object
#' @examples
fx.hbv.model.serial<-function(prm = NULL,
                              input, #data
                              Snow2GlacierOption = TRUE,#convert snow tro glacier at end of hydrological year
                              Snow2GlacierJulianDate= as.Date("2000-09-01"), #For calc of Snow2GlacierJulianday
                              calibrate=TRUE, # makes the function return obj.crit if TRUE to enable optimisation
                              obj.criteria="NSE", # chhose an objective criteria
                              icall=1){
  #comment after testing
  # prm<-NULL
  # input<-fx.hbv.daily.getdata(dir="D:/WORK/Tools/R/Packages and Apps/ejjhydrotools/data/hbv",
  #                             Timeseries ="Timeseries.txt",
  #                             Free_Par.txt="Free_Par.txt",
  #                             Fixed_Par.txt="Fixed_Par.txt",
  #                             serie.start.date="2020-09-01")
  # Snow2GlacierOption = TRUE
  # Snow2GlacierJulianDate= as.Date("2000-09-01")
  # calibrate=TRUE
  # obj.criteria="NSE"
  # icall=1

  #inputs
  fri<-input$data$fri
  fxd<-input$data$fxd
  zones<-input$data$zones
  timeseries<-input$data$timeseries

  #Free parameters
  if(!is.null(prm)){fri[,2] =prm}#read from prm and update fri
  prm<-fri[,2];names(prm)<-fri[,1]
  PKORR= prm[1];SKORR= prm[2];HPKORR= prm[3];TX= prm[4];#snow/rain
  TS= prm[5];CX= prm[6];CPRO= prm[7];PRO = prm[8]; #snowmelt
  FC= prm[9];BETA= prm[10];LP= prm[11];#Soil mositure
  KUZ2= prm[12];KUZ1= prm[13];UZ1= prm[14];PERC= prm[15];KLZ= prm[16];
  GCX= prm[17];#galcier melt
  Tlp= prm[18];Tlo= prm[19];
  SM0= prm[20]*FC; ##initial SM SMO is SMO/FC so we have converted it to mm here
  UZ0= prm[21];LZ0= prm[22]#initial upper and lower zone


  #zonal data
  zone.names<-zones[,1]
  zone<-as.data.frame(t(zones[,-1]))
  names(zone)<-zone.names
  nZ<-nrow(zone)
  z<-zone$masl
  SN0<-zone$SNO #initial snow by zone
  SW0<-zone$SWO #initial snow water by zone
  gIce<-zone$gIce #initial glacier proportion per zone in %


  #Precipitation lapse rates
  hpkorr<-rep( HPKORR,nZ)

  #Mountain Melt Increase factor MiMt
  #not implemented so set to one (forests)
  #can be larger for bare mountains
  MiMt = 1;


  #Fixed parameters
  Zp=fxd$V2[1];#elevation of precipitation station
  Zt=fxd$V2[2];#elevation of temperature station
  pLKs=fxd$V2[3]; #"lake percentage"
  Akm2 = fxd$V2[4]; #VCatchment area

  #data
  DY = nrow(timeseries)#length of dataset
  tp<-timeseries$Temp
  pr<-timeseries$Prec
  PE<-timeseries$PET
  Qobs<-timeseries$Qobs
  Time<-timeseries$Date
  JULIANS<-timeseries$jdate
  Snow2GlacierJulianDay<-fx.julian.day(Snow2GlacierJulianDate)


  #model result containers
  ##zonal
  P<- array(0,dim=c(DY,nZ))#Precipitation for each zone
  Ta<- array(0,dim=c(DY,nZ)) #Temperature for each zone
  R<- array(0,dim=c(DY,nZ)) #Rainfsll for each zone
  S<- array(0,dim=c(DY,nZ)) #Snowfall for each zone
  SN<- array(0,dim=c(DY,nZ)) # Dry Snow for each zone
  ATM<-array(0,dim=c(DY,nZ)) # Snow that is available to melt
  M<-array(0,dim=c(DY,nZ)) # Snow melt
  SW<-array(0,dim=c(DY,nZ)) # Snow water
  FR<-array(0,dim=c(DY,nZ)) # Snow freeze
  ST<-array(0,dim=c(DY,nZ)) # Snow water threshold
  #Portion of rainwater that is converted to snow water when there is a snow water defict
  RainToSW<-array(0,dim=c(DY,nZ))
  SWToSoil<-array(0,dim=c(DY,nZ)) #Excess sow water that goes to soil
  InS<-array(0,dim=c(DY,nZ)) #remaining rainwater that goes to INSOIL
  SNOW = array(0,dim=c(DY,nZ)) #Total Snow
  GM = array(0,dim=c(DY,nZ)) #Glacier melt

  #model result containers
  #Not zonal
  Pav = array(0,dim=c(DY,1)) #Average Areal Prec
  Tav =  array(0,dim=c(DY,1)) #Average Temperature
  SNOWav = array(0,dim=c(DY,1)) #Average Snow
  SnowCover = array(0,dim=c(DY,1)) #Snow cover
  Meltav =  array(0,dim=c(DY,1)) #Average Melt
  INSOIL =  array(0,dim=c(DY,1)) #Average INSOIL
  GMLT =  array(0,dim=c(DY,1)) #Average Glacier Melt
  SM =  array(0,dim=c(DY,1)) #Soil mositure
  EA =  array(0,dim=c(DY,1)) #Actual Evapotranspiration
  dUZ =  array(0,dim=c(DY,1)) # direct runff
  UZ =  array(0,dim=c(DY,1)) # Upper Zone
  LZ =  array(0,dim=c(DY,1)) # Lower Zone
  perc =  array(0,dim=c(DY,1)) # Percolation to Lower Zone
  QUZ1 =  array(0,dim=c(DY,1)) # Flow upper zone 1;mm
  QUZ2 =  array(0,dim=c(DY,1)) # Flow upper zone 2;mm
  QLZ =  array(0,dim=c(DY,1)) # Flow lower zone;mm
  Qsim  =  array(0,dim=c(DY,1)) # Flow m3/s



  for (tstep in 1:DY){
    #Snow Routine #######################################
    for (zn in 1:nZ){ #for each elevation zone

      #calculate rainfall and snowfall
      #temperature at precipitation gauge calculated from lapse rate and temp gauge elevation
      TZp =tp[tstep] + (Zt -Zp) / 100 * Tlp;
      #corrected rainfall
      if (TZp > TX) {prc = PKORR *pr[tstep]}else { prc = SKORR *pr[tstep] }

      #Lapse precipitation
      P[tstep,zn] = max((prc * (1 + ((z[zn] -Zp) / 100) * hpkorr[zn] / 100)), 0);

      #lapse Temperature
      TLR = Tlo #temperature lapse rate is either wet (Tlp) or dry (Tlo)
      if (P[tstep,zn] > 0) { TLR = Tlp; } else { TLR = Tlo; }
      Ta[tstep,zn] =tp[tstep] + TLR * (z[zn] -Zt) / 100;

      #Rainfall & snow fall for eath zone
      #R[tstep,zn] = (Ta[zn] > TX) ?P[tstep,zn] : 0;
      if(Ta[tstep,zn] > TX){R[tstep,zn]<-P[tstep,zn]}else{R[tstep,zn]<-0}
      S[tstep,zn] =P[tstep,zn] -R[tstep,zn];

      #Snow-routine
      #Begin snow storage % cumulating per tstep
      if (zn == 1) {SnowCover[tstep] = 0}

      #Melt M
      CX = MiMt*CX #in future cosider separating melt in mountains and forests. Mimt=1 forests and >1 mts
      Mmax<-0
      Mmax1 = CX * (Ta[tstep,zn] - TS); #maximum melt capacity
      if(0 > Mmax1){Mmax = 0 } else {Mmax = Mmax1}#real melt Capacity shouldnt be less than 0

      #Existing snow
      SNE = 0;#initialize #existing dry snow temporary variable
      if (tstep == 1){ SNE =SN0[zn]}else {SNE =SN[tstep - 1,zn]};#existing dry snow
      #Snow2Glacier
      if ((JULIANS[tstep] ==Snow2GlacierJulianDay) & (Snow2GlacierOption == TRUE)) { SNE = 0; }

      #Snow available to melt
      ATM[tstep,zn] = SNE +S[tstep,zn];
      #M[tstep,zn] = (ATMS[tstep,zn] > Mmax) ? Mmax : ATMS[tstep,zn];
      if(ATM[tstep,zn] > Mmax){M[tstep,zn] =Mmax}else{M[tstep,zn] = ATM[tstep,zn]}

      #dry snow state
      SN[tstep,zn] = max(SNE +S[tstep,zn] -M[tstep,zn], 0);
      SN[tstep,zn] = SNE +S[tstep,zn] -M[tstep,zn];

      #Refreeze snow water
      Fmax=0
      Fmax1 = CX * PRO* (TS -Ta[tstep,zn]);
      if(0 > Fmax1) {Fmax =0 } else {Fmax =Fmax1} #freeze capacity

      SWE=0;#initialize #existing snow water temporary variable
      if (tstep == 1) {SWE = SW0[zn]} else {SWE =SW[tstep - 1,zn]} #exisiting snow water
      #Snow2Glacier
      if ((JULIANS[tstep] ==Snow2GlacierJulianDay) & (Snow2GlacierOption == TRUE)) { SWE = 0}
      ATF = SWE;#available to fz
      if(ATF > Fmax) {FR[tstep,zn] = Fmax} else {FR[tstep,zn] = ATF}

      #Snow water State
      ST[tstep,zn] = CPRO * 0.01*SN[tstep,zn];#max free water
      SW1 = SWE +M[tstep,zn] -FR[tstep,zn];
      SN[tstep,zn] =SN[tstep,zn] +FR[tstep,zn];# Add re-freeze to dry-snow 22-12-2011
      swd =ST[tstep,zn] - SW1;# snow water deficit after melt and freeze
      #update SW1 if greater than ST
      ##check effect in result
      ##possibley ipdate cpp model to show eefetcive melt(SWToSoil)
      if(swd<0){
        SWToSoil[tstep,zn]=SW1-ST[tstep,zn] #effective snow melt
        SW1=ST[tstep,zn]
        swd=0} else {
          SWToSoil[tstep,zn]=0;
          SW1=SW1
          swd=swd
          }
      if(swd >R[tstep,zn]) {RainToSW[tstep,zn] =R[tstep,zn]} else { RainToSW[tstep,zn] =swd};
      SW[tstep,zn] = SW1 +RainToSW[tstep,zn];

      #Total SNOW
      SNOW[tstep,zn] =SN[tstep,zn] +SW[tstep,zn];
      #track snow storage cover in each zone 22-12-201
      if (SNOW[tstep,zn] > 0) {SnowCover[tstep] = SnowCover[tstep] + 10; }

      #To soil moisture
      InS[tstep,zn] =R[tstep,zn] - RainToSW[tstep,zn] + SWToSoil[tstep,zn];

      #Glacier Melt
      #Goes directlt to upper zone
      if (SN[tstep,zn] < 0.01){
        GM[tstep,zn] = GCX * CX * max(Ta[zn] - TS, 0) * (gIce[zn] / 100);
      }   else {GM[tstep,zn] = 0}

    } #End elevation zones

    #calculate Averages of zonal parameters for timestep
    Pav[tstep] = mean(P[tstep,],na.rm=TRUE);#Average Areal Prec
    SNOWav[tstep] = mean(SNOW[tstep,],na.rm=TRUE);#Average Snow
    Meltav[tstep] =  mean(SWToSoil[tstep,],na.rm=TRUE);#Average Melt
    INSOIL[tstep] =  mean(InS[tstep,],na.rm=TRUE);#Average INSOIL
    GMLT[tstep] =  mean(GM[tstep,],na.rm=TRUE);#Average Glacier Melt
    Tav[tstep] =  mean(Ta[tstep,],na.rm=TRUE);#Average Glacier Melt

    ##Soil Routine #######################################
    SMi=0;#starting Soil Mosture SMO (can be as a % of FC in par-file)
    if (tstep == 1) { SMi = SM0 } else { SMi = (SM[tstep - 1]); } #SM0

    #Actual Evaporation
    evap1=0;evap2=0; #22-12-2011
    evap1 = PE[tstep] * (1 -SnowCover[tstep] / 100); # SM>LP
    evap2 = PE[tstep] * SMi / (LP / 100 * FC) * (1 -SnowCover[tstep] / 100);# SM<=LP
    EA[tstep] = min(evap1, evap2);#22-12-2011

    #Soil Moisture Water Balance
    SMdef = FC - SMi;
    dUZ[tstep] = max((INSOIL[tstep] - SMdef -EA[tstep]),INSOIL[tstep] * ((SMi / FC)^BETA));
    dSM =INSOIL[tstep] - dUZ[tstep];
    SM[tstep] = max(0,SMi + dSM -EA[tstep]); #check this in c++

    ##Dynamic Routine #######################################
    ###UPPER ZONE
    UZi=0 #temp UZ
    if (tstep == 1){ UZi = UZ0;} else {UZi = UZ[tstep - 1];} #initital conditions
    UZ[tstep] = UZi + dUZ[tstep] +GMLT[tstep];
    if(UZ[tstep] < PERC){ perc[tstep] = UZ[tstep]}else{ perc[tstep] = PERC}
    UZ[tstep] =UZ[tstep] - perc[tstep];
    QUZ1[tstep] = min(UZ[tstep], UZ1) * KUZ1;
    QUZ2[tstep] = max(UZ[tstep] - UZ1, 0) * KUZ2;
    UZ[tstep] = UZ[tstep] - (QUZ1[tstep] + QUZ2[tstep]);#Update State

    #LOWER ZONE
    if (tstep == 1){LZi = LZ0} else {LZi =LZ[tstep - 1]}#initital conditions
    LZ[tstep] = LZi + perc[tstep] + (Pav[tstep] -PE[tstep]) * (pLKs / 100);
    LZ[tstep] = max(LZ[tstep], 0);#To prevent negative LZ
    QLZ[tstep] =LZ[tstep] * KLZ;
    LZ[tstep] =LZ[tstep] - QLZ[tstep];#Update State

    #QSIM
    ##hard-coded daily flow m3/s with 24*3.6.
    ###modified added the multiplier *(1-pLKs/100) 22-03-2011
    Qsim[tstep] = ((QUZ1[tstep] + QUZ2[tstep]) * (1 -pLKs / 100) + QLZ[tstep]) * (Akm2 / (86.4));


  }#end  t-steps

  #objective criteria
  NSE<-fx.nse(Qsim,Qobs)
  VE<-fx.kge(Qsim,Qobs)
  NSE.VE<-fx.nse(Qsim,Qobs,with.VE=TRUE)
  KGE<-fx.kge(Qsim,Qobs)
  objective.criteria<-data.frame(NSE,VE,NSE.VE,KGE)
  i.return<-which(names(objective.criteria) ==obj.criteria)
  OBJ<-objective.criteria[,i.return]

  #list of results
  Zonal<-list(Precipitation=P,Temperature=Ta,Rainfall=R,Snowfall=S,
              SnowDry=SN,AvailableToMelt=ATM,Melt=M,SnowWater=SW,Refreeze=FR,
              SnowWaterThreshold=ST,RainToSW=RainToSW,SWToSoil=SWToSoil,
              SnowTotal = SNOW,GlacierMelt = GM,
              InSoil=InS)

  Lumped<- data.frame(Precipitation= Pav,Temperature= Tav,
                      SnowStorage = SNOWav,
                      SnowCoverPercentage =SnowCover,
                      SnowMeltWater = Meltav,
                      GlacierMelt= GMLT,
                      INSOIL = INSOIL,
                      SoilMositure= SM,ActualEvaporation= EA,DirectToUZ = dUZ,
                      UpperZone =UZ,LowerZone = LZ,
                      Percolation = perc,
                      QUZ1 = QUZ1, QUZ2 = QUZ2, QLZ = QLZ,
                      Qsim = Qsim,
                      Qobs = Qobs)

  AvQobs<-sprintf("%5.2f",mean(Qobs,na.rm=TRUE))
  AvQsim<-sprintf("%5.2f",mean(Qsim,na.rm=TRUE))
  #return
  if(calibrate==TRUE){
    objdf<-round(objective.criteria,2)
    for(k in 1:length(objdf)){objdf[k]<-sprintf("%5.2f",objdf[k]) }

    ishow<-cbind(icall,obj.criteria,OBJ=round(OBJ,2),objdf,AvQobs,AvQsim)
    names(ishow)[1]<-c("HBV_RUN:")
    if (icall == 1||icall %% 500 == 0) {
      if (icall > 0) {print(ishow)}
    }
    return(OBJ)
  } else {
    out<-list(Zonal=Zonal,Lumped=Lumped,objective.criteria=objective.criteria,AvQobs,AvQsim)
    fx.plot.hbv.calib(Qsim = Qsim,Qobs = Qobs,Time=Time)
    return(out)
  }


} #end function



#' This is the hbv model for the given parametes and entire dataset
#' But runs each hydrological year independently and
#' reuses the initial conditions for each hydrological year
#' useful for calibration for year by ear
#' @import zoo
#' @import dplyr
#' @import readxl
#' @import tidyverse
#' @import gdata
#' @param prm free-parameters
#' @param input inputdata from fx.hbv.daily.getdata()
#' @param Snow2GlacierOption TRUE, convert snow to glacier at end of hydrological year
#' @param Snow2GlacierJulianDate  as.Date("2000-09-01"), Date for calc of Snow2GlacierJulianday.
#' @param calibrate Makes the function return obj.crit if TRUE to enable optimisation
#' @param obj.criteria Choose an optmising objective criteria from ("NSE","VE","NSE.VE","KGE"),
#' @param hyears  Provide hydrological years to run. if NULL all years in dataset are used
#' @param icall controls printing of visual obj.criteria during calibration if provided by external calib function
#' @return either objective critria or results object
#' @examples
fx.hbv.model.parallel<-function(prm=NULL,
                                input, #data
                                Snow2GlacierOption = TRUE,#convert snow tro glacier at end of hydrological year
                                Snow2GlacierJulianDate= as.Date("2000-09-01"), #For calc of Snow2GlacierJulianday
                                calibrate=TRUE, # makes te dunction return obj.crit if TRUE to enable optimisation
                                obj.criteria="NSE", # chhose an objective criteria),
                                icall=1,
                                hyears=NULL #provide hydrological years to run. if NULL all are used
){
  library(dplyr)
  if(is.null(hyears)){hyears<-input$data$hyear} else {hyears=hyears}
  nhyr<-length(hyears)
  out<-vector("list",length = nhyr)
  names(out)<-hyears
  par(mfrow=c(ceiling(nhyr/2),2))

  for(i in 1:nhyr){
    hyr.input<-input
    hyr.input$data$timeseries<-input$data$timeseries %>% filter(hyear==hyears[i]) #susbset data
    hyr.input$data$hyear=hyears[i]
    hyr.input$data$serie.start.date = hyr.input$data$timeseries$Date[1]
    out[[i]]<-fx.hbv.model.serial(prm=prm,
                                  input=hyr.input,
                                  Snow2GlacierOption = Snow2GlacierOption,
                                  Snow2GlacierJulianDate= Snow2GlacierJulianDate,
                                  calibrate=calibrate,
                                  obj.criteria = obj.criteria,
                                  icall = 1)
  }
  par(mfrow=c(1,1))
  obj1<-lapply(out,function(x) x["objective.criteria"])
  objective.criteria<-do.call(rbind,lapply(obj1,function(x)x[[1]]))
  objdf<-apply(objective.criteria,2,function(x) sprintf("%5.2f",x))
  i.return<-which(names(objective.criteria) ==obj.criteria)
  OBJ<-objective.criteria[,i.return]
  OBJ<-mean(OBJ)


  if(calibrate==TRUE){

      return(OBJ)

  } else {
    # to be developed
    title(main=paste("\nOBJ =", sprintf("%5.2f",OBJ)),outer=TRUE)
    return(out)

  }

}



