#https://github.com/quarto-dev/quarto-cli/discussions/2307
#Building quarto vignettes

.onLoad <- function(libname, pkgname) {
  tools::vignetteEngine(name = "quarto",
                        package = pkgname,
                        pattern = "[.]qmd$",
                        weave = function(file, ..., encoding = "UTF-8") {
                          message("Hello from custom Quarto vignette engine!")
                          ## TODO: What is Quarto's expectation about encoding?
                          ## NB: output_format = "all" below might make a better default
                          quarto::quarto_render(file, ..., output_format = "pdf")
                        },
                        tangle = tools::vignetteEngine("knitr::rmarkdown")$tangle,
                        aspell = tools::vignetteEngine("knitr::rmarkdown")$aspell
  )
}
