library(DiagrammeR)

# fx.draw.system
#
# This functions draws a flow chart based on data in an xls file
# Nodes are in a sheet call Nodes. case sensitive
# Edges are in a sheet called edges. case sensitive

#' This functions draws a flow chart based on data in an xls file
#' @import DiagrammeR
#' @import readxl
#' @import tidyverse
#' @param nodes_edges_xls path to xls file with niods and edges. temlate is provided
#' @param rankdir rankdirection. can be "LR" or "TB".
#' @param bgcolor background color
#' @return a Grphiz graph obkect.
#' @examples
#' fx.draw.system(system.file(system.file("data/Flowchart_Nodes_and_edges.xlsx",package = "ejjhydrotools")))
fx.draw.system<-function(nodes_edges_xls,
                         rankdir="LR",
                         bgcolor="#8080800D"){
  library(DiagrammeR)
  #https://rich-iannone.github.io/DiagrammeR/articles/graphviz-mermaid.html
  #attributes
  #https://graphviz.org/docs/attrs/dir/
  #graph https://graphviz.org/docs/graph/
  #
  library(readxl) #https://readxl.tidyverse.org/
  library(tidyverse)
  Nodes<-read_excel(nodes_edges_xls, sheet = "Nodes")
  Edges<-read_excel(nodes_edges_xls, sheet = "Edges")
  #creating a node data frame
  # N=29 #29
  # Nodes<-Nodes[1:N,] ; print(Nodes,n=N);
  # E=27 #27
  # Edges<-Edges[1:E,] ; print(Edges,n=E)
  nodes<- create_node_df(n= nrow(Nodes),
                         style= Nodes$style,
                         label= Nodes$label,
                         color= Nodes$color,
                         shape= Nodes$shape,
                         fillcolor=Nodes$fillcolor,
                         width=Nodes$width,
                         height=Nodes$height,
                         fixedsize=Nodes$fixedsize,#stretch to fit the words
                         fontcolor=Nodes$fontcolor,
                         fontsize= Nodes$fontsize)
  # data frame of edges
  edges<-create_edge_df(from = Edges$from,
                        to=Edges$to,
                        label = Edges$label,
                        rel= Edges$rel,
                        color= Edges$color,
                        fontcolor=Edges$fontcolor,
                        style=Edges$style,
                        arrowhead=Edges$arrowhead,
                        dir=Edges$dir,
                        fontsize=Edges$fontsize
  )
  graph<-create_graph(nodes, edges) %>%
    add_global_graph_attrs(
      attr = c("layout", "rankdir", "splines","bgcolor"),
      value = c("dot", rankdir, "false",bgcolor),
      attr_type = c("graph", "graph", "graph","graph"))
  graf<-render_graph(graph)
  return(graf)
}

#' fx.draw.system.clusters
#'
#' This functions draws a flow chart based on data in an xls file
#' Includes option for draawing clusters
#' cluster data is also in the xls file

#' This functions draws a flow chart based on data in an xls file
#' @import DiagrammeR
#' @import readxl
#' @import tidyverse
#' @param nodes_edges_xls path to xls file with niods and edges. temlate is provided
#' @param rankdir rankdirection. can be "LR" or "TB".
#' @param bgcolor background color
#' @param splines Determines how the nodes are connected. can be "true","ortho","line","none","curved","spline","polyline"
#' @return a Grphiz graph obkect.
#' @examples
#' fx.draw.system(system.file(system.file("data/Flowchart_Nodes_and_edges.xlsx",package = "ejjhydrotools")))
fx.draw.system.clusters<-function(nodes_edges_xls,
                                  rankdir="LR",
                                  bgcolor="#8080800D",
                                  splines="true"
                                  #ortho,line,none,curved,spline,polyline
){
  #library(DiagrammeR)
  #https://rich-iannone.github.io/DiagrammeR/articles/graphviz-mermaid.html
  #attributes
  #https://graphviz.org/docs/attrs/dir/
  #graph https://graphviz.org/docs/graph/
  #
  library(readxl) #https://readxl.tidyverse.org/
  library(tidyverse)
  Nodes<-read_excel(nodes_edges_xls, sheet = "Nodes")
  Edges<-read_excel(nodes_edges_xls, sheet = "Edges")
  #creating a node data frame
  # N=29 #29
  # Nodes<-Nodes[1:N,] ; print(Nodes,n=N);
  # E=27 #27
  # Edges<-Edges[1:E,] ; print(Edges,n=E)
  nodes<- create_node_df(n= nrow(Nodes),
                         style= Nodes$style,
                         label= Nodes$label,
                         color= Nodes$color,
                         shape= Nodes$shape,
                         fillcolor=Nodes$fillcolor,
                         width=Nodes$width,
                         height=Nodes$height,
                         fixedsize=Nodes$fixedsize,#stretch to fit the words
                         fontcolor=Nodes$fontcolor,
                         fontsize= Nodes$fontsize,
                         cluster= Nodes$cluster)
  # data frame of edges
  edges<-create_edge_df(from = Edges$from,
                        to=Edges$to,
                        label = Edges$label,
                        rel= Edges$rel,
                        color= Edges$color,
                        fontcolor=Edges$fontcolor,
                        style=Edges$style,
                        arrowhead=Edges$arrowhead,
                        dir=Edges$dir,
                        fontsize=Edges$fontsize,
                        penwidth=Edges$penwidth,
                        splines=Edges$splines
  )
  graph<-create_graph(nodes, edges) %>%
    add_global_graph_attrs(
      attr = c("layout", "rankdir", "splines","bgcolor","splines"),
      value = c("dot", rankdir, "false",bgcolor,splines),
      attr_type = c("graph", "graph", "graph","graph","graph"))
  graf<-render_graph(graph)
  return(graf)
}

