#test
cat("\014")
source("D:/WORK/Tools/R/Packages and Apps/ejjhydrotools/R/hbv.R", echo=TRUE)
#input the data
graphics.off()
input<-fx.hbv.daily.getdata(dir="D:/WORK/Tools/R/Packages and Apps/ejjhydrotools/data/hbv",
                            Timeseries ="Timeseries.txt",
                            Free_Par.txt="Free_Par.txt",
                            Fixed_Par.txt="Fixed_Par.txt",
                            serie.start.date="2020-09-01")
prm<-input$data$fri[,2]
calib.serial.out<-fx.hbv.model.serial(prm=prm,
                                      input=input,
                                      Snow2GlacierOption = TRUE,
                                      Snow2GlacierJulianDate= as.Date(2020-09-01),
                                      calibrate=TRUE,
                                      obj.criteria = "NSE",
                                      icall = 1)

results.serial.out<-fx.hbv.model.serial(prm=NULL,
                                        input=input,
                                        Snow2GlacierOption = TRUE,
                                        Snow2GlacierJulianDate= as.Date(2020-09-01),
                                        calibrate=FALSE,
                                        obj.criteria = "NSE",
                                        icall = 1)

calib.parallel.out<-fx.hbv.model.parallel(prm=NULL,
                                        input=input,
                                        Snow2GlacierOption = TRUE,
                                        Snow2GlacierJulianDate= as.Date("2020-09-01"),
                                        calibrate=TRUE,
                                        obj.criteria = "NSE",
                                        icall = 1)

results.parallel.out<-fx.hbv.model.parallel(prm=NULL,
                                            input=input,
                                            Snow2GlacierOption = TRUE,
                                            Snow2GlacierJulianDate= as.Date("2020-09-01"),
                                            calibrate=FALSE,
                                            obj.criteria = "NSE",
                                            icall = 1)
# For testing
prm<-NULL
Snow2GlacierOption = TRUE
Snow2GlacierJulianDate= as.Date("2020-09-01")
calibrate=FALSE
obj.criteria = "NSE"
icall = 1
hyears=NULL
