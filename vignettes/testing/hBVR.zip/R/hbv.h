//This is hbv.h
#pragma once
//disable warnings associated with fopen
#pragma once
#define _CRT_SECURE_NO_DEPRECATE 1
#include "JulianDayCalc.h"
#include <iostream> //enables output & input
#include <fstream>
#include <string>
#include <algorithm>
#include <stdio.h>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <direct.h> // for getcwd
#include <stdlib.h>// for MAX_PATH
#include <time.h>
#include<array>

using namespace std;

#define star "\n********************************************************************************\n"
#define star2 "\n********************************************************************************\n\n"
#define lnz	 "\n*------------------------------------------------------------------------------------------------------------------*\n"
#define lnz2 "*-----------------------------------------------------------------------------------------------------------------*\n\n"
#define fmt1 setw(12)<<setprecision(4)<<fixed
#define fmt setw(8)<<fixed<<"\t"
#define fmt2 fmt1<<setprecision(2)
#define fmt3 setw(12)<<fixed
#define fmt4 setw(8)<<setprecision(2)<<fixed


//Global Static functions
void replaceChars(string& modifyMe, const string& findMe, const string& newChars) //: C03:Replace.cpp
{
  // Look in modifyMe for the "find string" starting at position 0:
  size_t itt = modifyMe.find(findMe, 0);
  // Did we find the string to replace? If yes, then Replace the find string with newChars:
  if (itt != string::npos) modifyMe.replace(itt, findMe.size(), newChars);
}
string replacestr(string modifyMe, const string& findMe, const string& newChars) //: C03:Replace.cpp
{
  string modified = modifyMe;
  // Look in modifyMe for the "find string" starting at position 0:
  size_t itt = modifyMe.find(findMe, 0);
  // Did we find the string to replace? If yes, then Replace the find string with newChars:
  if (itt != string::npos) modifyMe.replace(itt, findMe.size(), newChars);
  return(modified);
}
template<class Tm>//Average of a 2d array for 10 items at time t	//call avg<float>(arrayname,t,zones)
Tm avg(Tm** data, int d, int n) { Tm sum = 0;for (int i = 0; i < n; i++) { sum = sum + data[i][d]; }	return (sum / n); }
template<class Tn>//average of a 1D array for all DY items	//call avg<float>(arrayname)
Tn avg(Tn* data, int d) { Tn sum = 0;for (int i = 0; i < d; i++) { sum = sum + data[i]; }return (sum / d); }
template<class Tnm>//Sum
Tnm summ(Tnm data[], int DY) { Tnm sum = 0;for (int i = 0; i < DY; i++) { sum = sum + data[i]; }return (sum); }

//void mysort(float* fn, int nN, float** &xp, int nn) #alternative delclaration BUT
// my sort is meant to bec alled from amember function of whatrever object to be modified
// In this case float ** xp
// If you call the mysort function from within a member function of the sce (object's) class, you can remove the & from the arguments.
// The & in the function signature float** &xp indicates that you are passing a reference to a pointer to a pointer to a float.
// If you are calling the function from within the class, you are working with the class's member variables directly,
//so you don't need to use a reference to modify them.
//https://chat.openai.com/c/72672424-6acb-4a60-944d-db3b7b9cc7fb
void mysort(float* fn, int nN, float** xp, int nn) {// sort arrays by one-array <<decreasing sort>> i.e msx->min
  float ftemp, * xtemp; xtemp = new float[nn];
  for (int c = 0;c < nN;c++)// to represent element to be compared
  {
    for (int j = (c + 1);j < nN;j++)// to represent the rest of the elements
    {
      if (fn[c] < fn[j])
      {
        ftemp = fn[c];    // swap  objective function
        fn[c] = fn[j];
        fn[j] = ftemp;
        for (int d = 0;d < nn;d++)
        {
          xtemp[d] = xp[c][d];//swap parameters
          xp[c][d] = xp[j][d];
          xp[j][d] = xtemp[d];
        }
      }
    }
  }
}
void Dsort(float* fn, int nN) {//decreasing float sort
  float ftemp;
  for (int c = 0;c < nN;c++)// to represent element to be compared
  {
    for (int j = (c + 1);j < nN;j++)// to represent the rest of the elements
    {
      if (fn[c] < fn[j])
      {
        ftemp = fn[c];    // swap  objective function
        fn[c] = fn[j];
        fn[j] = ftemp;
      }
    }
  }
}
void Isort(int* fn, int nN) {//increasing integers sort

  int ftemp;
  for (int c = 0;c < nN;c++)// to represent element to be compared
  {
    for (int j = (c + 1);j < nN;j++)// to represent the rest of the elements
    {
      if (fn[c] > fn[j])
      {
        ftemp = fn[c];    // swap  objective function
        fn[c] = fn[j];
        fn[j] = ftemp;
      }
    }
  }
}
//Function to find highest (maximum) value in array
// Returns the maximum value in an array.
float maximumValue(float* a, int size) {
  //assert(size > 0);        // Note 1.
  float maxVal = a[0];     // Note 2.
  for (int i = 1; i < size; i++) {
    if (a[i] > maxVal) {
      maxVal = a[i];
    }
  }
  return maxVal;
}//end max
float rndup(float x) {//round to 2dp
  float f, xi, xf;
  xf = modf(x, &xi);
  f = (float)floor((float)(xf * 100 + 0.5)) / 100.0;
  return xi + f;
}
int* breakdotstring(string str)
{
  string word;
  int* DATO = new int[3];
  stringstream stream(str);
  int i = 0;
  while (getline(stream, word, '.')) {
    DATO[i] = atoi(word.c_str());cout << DATO[i] << "\n";
    i = i + 1;
  }
  return(DATO);
}

// function to return the current working directory
// this is generally the application path

void GetCurrentPath(char* buffer) { _getcwd(buffer, _MAX_PATH); }



class hbv {
public:
  //VARIABLES

  //input
  string projdir;
  int DY;//Days
  float* pr, * tp, * PE, * Qobs;int* Date;//input data
  string ts, par, fxd;//input files
  float Zp, Zt, pLKs, Akm2;string cz[10];//fixed zonal params
  float prm[33], bU[33], bL[33], bestprm[33];//free parameters & bounds
  int FLG[33]; // FLAG for parameter study = 1 (for only 2 parameters to study) and = 0 for others
  string cp[33];
  float z[10], gIce[10], SN0[10], SW0[10]; int FOR[10];//elevation, glacier & snow initial and Forest percentage
  float* Sstor;//snow storage precentage
  float** SNOW, ** SW, ** SN, ** GM, ** InS;//snow, glacier melt, Insoil for @ zone
  float* SNOWav, * GMLT, * INSOIL, * Pav, * Tav, * EA, * Qsim;
  float MiMt; //Melt increase factor in mountain
  int diFL;// iff difefrent lapse for prec for @ zone diffL=1,else 0
  float* SM, * UZ, * LZ;
  float RSQ, NSeff, RVE, AvQsim, AvQobs;
  float* P, * T, * R, * S, * M, * ST, * F, * rw;
  int RSQtype; // option to decide which objective criteria to use RSQtype=0: RSQ Nash & RSQtype=1 RSQ & Water Balance

  int* JULIANS, Snow2GlacierOption, Snow2GlacierJulianDay; string dato, * sdate; // Added 02-01-2012 to caterfor new arg.txt for snow at end of season

  //FUNCTIONS
  hbv();	hbv(string, string, string, int, int, int, int, string, int);	~hbv();
  int getDaYs();
  void getdat();//read tsfile
  void getpar();//read par
  void foutpar();// save par
  void outpar();//par to screen
  float hbvmodel(int, int);//hbv model
  void foutRSQ();// RSQ to file
  // res to file
  void flowresults();
  void snowresults();
  //Serial vs parallel
  int parallel; //decides if we run a serial on parallel simulation
  float* RSQparallel, * RVEparallel, * NSeffparallel;//contains the RSQ for parallel simulations
  int* hyear, nhyrs, * hyrs; //hydrological year for each date and number of hydrological years in simulation
  float* PAvQobs, * PAvQsim;//Averages for parallel water balances
};
//hbv functions
hbv::hbv(string ts, string par, string fxd, int diFL, int RSQtype, int Snow2GlacierOption, int Snow2GlacierJulianDay, string dato, int parallel) {
  this->diFL = diFL;
  this->RSQtype = RSQtype;
  //Water Balance Initial values
  this->AvQsim = 0;
  this->AvQobs = 0;
  this->NSeff = 0;
  this->RVE = 0;
  //files
  this->ts = ts;this->par = par;this->fxd = fxd;
  //Days
  this->DY = getDaYs();
  //parameters
  getpar();//foutpar();
  //get ts
  this->Date = new int[this->DY];
  this->pr = new float[this->DY];
  this->tp = new float[this->DY];
  this->PE = new float[this->DY];
  this->Qobs = new float[this->DY];
  getdat();

  //Other arrays
  int zn;
  this->P = new float[10];
  this->T = new float[10];
  this->R = new float[10];
  this->S = new float[10];
  this->M = new float[10];
  this->ST = new float[10];
  this->F = new float[10];
  this->rw = new float[10];
  this->SN = new float* [10];for (zn = 0; zn < 10; zn++) { this->SN[zn] = new float[this->DY]; }
  this->SNOW = new float* [10];for (zn = 0; zn < 10; zn++) { this->SNOW[zn] = new float[this->DY]; }
  this->GM = new float* [10];for (zn = 0; zn < 10; zn++) { this->GM[zn] = new float[this->DY]; }
  this->InS = new float* [10];for (zn = 0; zn < 10; zn++) { this->InS[zn] = new float[this->DY]; }
  this->SW = new float* [10];for (zn = 0; zn < 10; zn++) { this->SW[zn] = new float[this->DY]; }
  this->SM = new float[this->DY];
  this->UZ = new float[this->DY];
  this->LZ = new float[this->DY];
  this->SNOWav = new float[this->DY];
  this->GMLT = new float[this->DY];
  this->Pav = new float[this->DY];
  this->INSOIL = new float[this->DY];
  this->Tav = new float[this->DY];
  this->EA = new float[this->DY];
  this->Qsim = new float[this->DY];
  this->Sstor = new float[this->DY];// Snow storage % 22-12-2011

  //To do with Snow2Glacierat end of season
  this->sdate = new string[this->DY];//date strings array
  this->JULIANS = new int[this->DY];//added 02-01-2012 to cater for Julian day number for Snow conversion at end of season
  this->dato = dato;
  this->Snow2GlacierJulianDay = Snow2GlacierJulianDay;
  this->Snow2GlacierOption = Snow2GlacierOption;
  this->hyear = new int[this->DY];//date strings array
  this->nhyrs = 1; //initialise number of hydrological years
  this->JULIANS = julian(this->dato, this->DY, 1, this->sdate, this->hyear, this->nhyrs); //Create Julian Dates for hbv object//get date series//year series//number of hyd years
  //Parallel or serial
  this->parallel = parallel;
  this->RSQparallel = new float[this->nhyrs];
  this->RVEparallel = new float[this->nhyrs];
  this->NSeffparallel = new float[this->nhyrs];
  this->PAvQobs = new float[this->nhyrs];
  this->PAvQsim = new float[this->nhyrs];
  this->hyrs = new int[nhyrs];//Contains the list of years (unique). Following lines populate it
  int ix = 0;
  for (int iy = 0;iy < this->DY;iy++) {
    if (iy == 0) { this->hyrs[ix] = this->hyear[iy]; }
    if (iy > 0) {
      if (this->hyear[iy] > this->hyear[iy - 1]) { ix = ix + 1;this->hyrs[ix] = this->hyear[iy]; }
    }
  }

};
hbv::~hbv() {};
int hbv::getDaYs() {
  //Count Lines
  int DY = 0;
  string cdts;
  string filepath;
  filepath = this->ts;
  ifstream inFile;
  inFile.open(filepath.c_str(), ios::in);
  if (!inFile) { cerr << "\nUnable to open " << this->ts.c_str() << "\n"; }
  string line;
  //Days in file
  if (inFile.is_open()) { while (!inFile.eof()) { getline(inFile, line);if (line != "") { DY = DY + 1; } } }
  inFile.close();
  DY = DY - 1;//IGNORE LAST LINE IN CASE BLANK
  return(DY);
}
void hbv::getdat() {
  //read data
  string cdts[5];
  string filepath;
  filepath = this->ts;//cout<<"\n"<<filepath.c_str()<<"\n";
  ifstream inFile;
  inFile.open(filepath.c_str(), ios::in);

  if (inFile.is_open()) {
    for (int c = 0;c < 5;c++) {
      inFile >> cdts[c];
      //cout<<fmt1<<cdts[c];
    }
    cout << "\n";
    for (int c = 0;c < this->DY;c++) {
      //cout<<c<<"\n";
      inFile >> Date[c];inFile >> this->pr[c] >> this->tp[c] >> this->PE[c] >> this->Qobs[c];
      //cout<<fmt1<<this->Date[c]<<fmt1<<this->pr[c]<<fmt1<<this->tp[c]<<fmt1<<this->PE[c]<<fmt1<<this->Qobs[c]<<"\n";
    }; //cin.get();//cout<<"finished reading\n";
  }

}
void hbv::getpar() {
  ifstream fxdFile;
  string filepath;filepath = this->fxd;
  fxdFile.open(filepath.c_str(), ios::in);//Open the file stream
  if (!fxdFile) { cerr << "\nUnable to open " << this->fxd.c_str() << "\n"; }
  //read zonal information //read parametersinFile>>Zp>>Zt>>pLKs>>Akm2;
  fxdFile >> this->cz[0] >> this->Zp >> this->cz[1] >> this->Zt >> this->cz[2] >> this->pLKs >> this->cz[3] >> this->Akm2;
  fxdFile >> this->cz[4];for (int c = 0;c < 10;c++) { fxdFile >> this->z[c]; }
  fxdFile >> this->cz[5];for (int c = 0;c < 10;c++) { fxdFile >> this->gIce[c]; }
  fxdFile >> this->cz[6];for (int c = 0;c < 10;c++) { fxdFile >> this->SN0[c]; }
  fxdFile >> this->cz[7];for (int c = 0;c < 10;c++) { fxdFile >> this->SW0[c]; }
  fxdFile >> this->cz[8];for (int c = 0;c < 10;c++) { fxdFile >> this->FOR[c]; }
  fxdFile.close();

  ifstream inFile;filepath = this->par;
  inFile.open(filepath.c_str(), ios::in);//Open the file stream
  if (!inFile) { cerr << "\nUnable to open " << this->par.c_str() << "\n"; }
  //Close the input stream//read parameters
  for (int i = 0;i < 33;i++) { inFile >> this->cp[i] >> this->prm[i] >> this->bL[i] >> this->bU[i] >> this->FLG[i]; }
  //PKORR,SKORR,HPKORR,TX,TS,CX,PRO,FC,BETA,LP,KUZ2,KUZ1,UZ1,PERC,GCX,Tlp,Tlo,SM0,UZ0,LZ0,hpkorr[0-10],MiMt
  inFile.close();
}
void hbv::foutpar() {
  string aname;
  //aname = this->fxd;//+".out";
  //ofstream fxdfile;
  //fxdfile.open(aname.c_str(),ios::out);//Open the file stream
  //if (!fxdfile){cerr << "\nUnable to open file parameter file";}
  ////read zonal information //read parametersinFile>>Zp>>Zt>>pLKs>>Akm2;
  //fxdfile<<this->cz[0]<<fmt1<<this->Zp<<"\n"<<this->cz[1]<<fmt1<<this->Zt<<"\n"<<this->cz[2]<<fmt1<<this->pLKs<<"\n"<<this->cz[3]<<fmt1<<this->Akm2<<"\n";
  //fxdfile<<this->cz[4];for (int c=0;c<10;c++){fxdfile<<fmt1<<this->z[c]<<fmt1;}
  //fxdfile<<"\n"<<this->cz[5];for (int c=0;c<10;c++){fxdfile<<fmt1<<this->gIce[c]<<fmt1;}
  //fxdfile<<"\n"<<this->cz[6];for (int c=0;c<10;c++){fxdfile<<fmt1<<this->SN0[c]<<fmt1;}
  //fxdfile<<"\n"<<this->cz[7];for (int c=0;c<10;c++){fxdfile<<fmt1<<this->SW0[c]<<fmt1;}
  //fxdfile<<"\n"<<this->cz[8];for (int c=0;c<10;c++){fxdfile<<fmt1<<this->FOR[c]<<fmt1;}
  //fxdfile.close();

  aname = this->par + ".OUT";
  ofstream infile;
  infile.open(aname.c_str(), ios::out);//Open the file stream
  if (!infile) { cerr << "\nUnable to open file parameter file"; }
  //Close the input stream//read parameters
  cout << "\n" << fmt1 << "SAVING: " << aname << "\n\tFree Parameters...";
  for (int i = 0;i < 33;i++) { infile << this->cp[i] << fmt1 << this->prm[i] << fmt1 << this->bL[i] << fmt1 << this->bU[i] << fmt1 << this->FLG[i] << "\n"; }
  //PKORR,SKORR,HPKORR,TX,TS,CX,PRO,FC,BETA,LP,KUZ2,KUZ1,UZ1,PERC,GCX,Tlp,Tlo,SM0,UZ0,LZ0,hpkorr[0-10]
  infile.close();
  cout << fmt1 << "\tDONE";
}
void hbv::outpar() {
  cout << this->cz[0] << fmt1 << this->Zp << "\n" << this->cz[1] << fmt1 << this->Zt << "\n" << this->cz[2] << fmt1 << this->pLKs << "\n" << this->cz[3] << fmt1 << this->Akm2 << "\n";
  cout << this->cz[4];for (int c = 0;c < 10;c++) { cout << fmt1 << this->z[c] << fmt1; }
  cout << "\n" << this->cz[5];for (int c = 0;c < 10;c++) { cout << fmt1 << this->gIce[c] << fmt1; }
  cout << "\n" << this->cz[6];for (int c = 0;c < 10;c++) { cout << fmt1 << this->SN0[c] << fmt1; }
  cout << "\n" << this->cz[7];for (int c = 0;c < 10;c++) { cout << fmt1 << this->SW0[c] << fmt1; }
  //Close the input stream//read parameters
  for (int i = 0;i < 33;i++) { cout << this->cp[i] << fmt1 << this->prm[i] << fmt1 << this->bL[i] << fmt1 << this->bU[i] << "\n"; }
  //PKORR,SKORR,HPKORR,TX,TS,CX,PRO,FC,BETA,LP,KUZ2,KUZ1,UZ1,PERC,GCX,Tlp,Tlo,SM0,UZ0,LZ0,hpkorr[0-10]
}
float hbv::hbvmodel(int icall, int RSQtype) {
  int i, t, zn;
  //Params
  float PKORR = this->prm[0];float SKORR = this->prm[1];float HPKORR = this->prm[2];float TX = this->prm[3];
  float TS = this->prm[4];float Cx = this->prm[5];float CPRO = this->prm[6];float PRO = this->prm[7];
  float  FC = this->prm[8];float BETA = this->prm[9];float LP = this->prm[10];float KUZ2 = this->prm[11];
  float  KUZ1 = this->prm[12];float UZ1 = this->prm[13];float PERC = this->prm[14];	float KLZ = this->prm[15];
  float  GCX = this->prm[16];float Tlp = this->prm[17];float Tlo = this->prm[18];	float SM0 = this->prm[19] / (float)100 * FC; //SMO is SMO%FC so we have converted it to mm here 22-12-2011
  float  UZ0 = this->prm[20];float LZ0 = this->prm[21];
  //Precipitation lapse rates
  float hpkorr[10];
  if (this->diFL == 0) { for (int i = 0;i < 10;i++) { hpkorr[i] = HPKORR; } } //Same all zones
  if (this->diFL == 1) { for (int i = 0;i < 10;i++) { hpkorr[i] = this->prm[i + 22]; } }// different each zone'
  //Mountain Melt Increase factor MiMt
  float  MiMt = this->prm[32];
  float CX; // CX value after checking for Forest or Mountain
  //cin.get();
  float TLR;//Temperature Lapse rate (pret & No-pret)
  float prc;

  //float *pr,*tp,*PE,*Qobs;int *Date;//input data
  float SMdef, dSM, dUZ;
  float Mmax, Mmax1, Mmax2, Fmax, Fmax1, Fmax2;
  float UZi, QUZ1, QUZ2, LZi, QLZ, perc;
  //Initial cumulative /average water balance
  this->AvQobs = 0;
  this->AvQsim = 0;

  int trackt = 0, miniDY, iRSQ = 0; //Used to track indics of t for when the hydrological year chnages

  //begin daily loops
  for (t = 0;t < this->DY;t++)//for each day of the data
    //for (int t=0;t<5;t++)//for each day of the data
  {
    //For initial conditions
    //only if parallel simulation is enabled
    //Check if the Hydrological year has changed except for the first day
    //if the hydrological year has changed revert to the file initial conditions
    //syntax if((t==0) | ((t>0) & ((this->parallel==1) &(this->hyear[t]>this->hyear[t-1]))))
    //2-1-2012

    for (zn = 0;zn < 10;zn++)//for each snow zone
    {

      if (zn == 0) { this->Sstor[t] = 0; } //begin sno storage % cumulating per zone 22-12-2011
      //Precipitation Correction
      //temperature at precipitation gauge calculated from lapse rate and temp gauge elevation
      float TZp; TZp = this->tp[t] + (this->Zt - this->Zp) / 100 * Tlp;

      //corrected rainfall
      if (TZp > TX) { prc = PKORR * this->pr[t]; }
      else { prc = SKORR * this->pr[t]; }

      //Lapse pretipitation
      this->P[zn] = max<float>((prc * (1 + ((this->z[zn] - this->Zp) / 100) * hpkorr[zn] / 100)), 0);

      //lapse Temperature
      if (this->P[zn] > 0) { TLR = Tlp; }
      else { TLR = Tlo; }
      this->T[zn] = this->tp[t] + TLR * (this->z[zn] - this->Zt) / 100;

      //Rainfall & snow fall for eath zone
      this->R[zn] = (this->T[zn] > TX) ? this->P[zn] : 0;
      this->S[zn] = this->P[zn] - this->R[zn];

      //printf("%i\t%i\t%4.2f\t%4.2f\t%4.2f\t%4.2f\n",zn,t,this->P[zn][t],this->T[zn],this->R[zn],this->S[zn]);

      //SNOW ROUTINE
      //Melt M
      if (this->FOR[zn] == 1) { CX = Cx; }
      else { CX = MiMt * Cx; } // Correct Forest or Mountain CX
      //cout<<this->FOR[zn]<<"\n";
      Mmax1 = CX * (this->T[zn] - TS);
      Mmax2 = 0;Mmax = (Mmax2 > Mmax1) ? Mmax2 : Mmax1;//melt Capatity

      float SNE;
      if ((t == 0) || ((t > 0) & ((this->parallel == 1) & (this->hyear[t] > this->hyear[t - 1])))) SNE = this->SN0[zn]; else SNE = this->SN[zn][t - 1];//exisiting dry snow
      if ((this->JULIANS[t] == this->Snow2GlacierJulianDay) & (this->Snow2GlacierOption == 1)) { SNE = 0; }//Added 2/1/2012 Snow2Glacier

      float ATM = SNE + this->S[zn];//available to melt
      this->M[zn] = (ATM > Mmax) ? Mmax : ATM;

      //dry snow state
      this->SN[zn][t] = max<float>(SNE + this->S[zn] - this->M[zn], 0);
      this->SN[zn][t] = SNE + this->S[zn] - this->M[zn];

      //Freexe M
      Fmax1 = CX * PRO / 100 * (TS - this->T[zn]);
      Fmax2 = 0;
      Fmax = (Fmax2 > Fmax1) ? Fmax2 : Fmax1;//frz capatity

      float SWE;
      if ((t == 0) | ((t > 0) & ((this->parallel == 1) & (this->hyear[t] > this->hyear[t - 1])))) SWE = SW0[zn]; else SWE = this->SW[zn][t - 1];//exisiting snow water
      if ((this->JULIANS[t] == this->Snow2GlacierJulianDay) & (this->Snow2GlacierOption == 1)) { SWE = 0; }//Added 2/1/2012 Snow2Glacier
      float ATF = SWE;//available to fz

      this->F[zn] = (ATF > Fmax) ? Fmax : ATF;

      //Snow water State
      this->ST[zn] = CPRO * float(0.01) * this->SN[zn][t];//max free water
      float SW1 = SWE + this->M[zn] - this->F[zn];
      this->SN[zn][t] = this->SN[zn][t] + this->F[zn];// Add re-freeze to dry-snow 22-12-2011

      float rw1 = this->ST[zn] - SW1;
      this->rw[zn] = (rw1 > this->R[zn]) ? this->R[zn] : rw1;

      this->SW[zn][t] = SW1 + this->rw[zn];

      //To soil moisture
      this->InS[zn][t] = this->R[zn] - this->rw[zn];

      //Total SNOW
      this->SNOW[zn][t] = this->SN[zn][t] + this->SW[zn][t];
      if (this->SNOW[zn][t] > 0) { this->Sstor[t] = this->Sstor[t] + 10; } //track snow storage cover in each zone 22-12-2011

      //Glacier Melt
      if (this->SN[zn][t] < 0.01)
        this->GM[zn][t] = GCX * CX * max<float>(this->T[zn] - TS, 0) * (this->gIce[zn] / 100);
      else this->GM[zn][t] = 0;
    }//End//End zone

    //calculate Averages avg<float>(arraypointer,elements)
    this->Pav[t] = avg<float>(this->P, 10);//Average Areal Prec
    this->SNOWav[t] = avg<float>(SNOW, t, 10);//Average Snow
    this->INSOIL[t] = avg<float>(InS, t, 10);//Average INSOIL
    this->GMLT[t] = avg<float>(GM, t, 10);//Average Glacier Melt
    this->Tav[t] = avg<float>(this->T, 10);//Average Glacier Melt

    //SOIL MOISTURE
    float SMi;//starting Soil Mosture SMO (can be as a % of FC in par-file)
    //if (t==0){SMi=((SM0)*(FC)/100);} else {SMi=(this->SM[t-1]);} // SM0%FC
    if ((t == 0) | ((t > 0) & ((this->parallel == 1) & (this->hyear[t] > this->hyear[t - 1])))) { SMi = SM0; }
    else { SMi = (this->SM[t - 1]); } //SM0 not SM0%FC //reset initital conditions for t=0 or when parallel sim & hydro year changes 2/1/2012

    //Actual Evaporation
    float evap1, evap2; //22-12-2011
    evap1 = this->PE[t] * (1 - this->Sstor[t] / 100); // SM>LP 22-12-2011
    evap2 = this->PE[t] * SMi / (LP / 100 * FC) * (1 - this->Sstor[t] / 100);// SM<=LP 22-12-2011
    //if (SMi>(LP/100*FC)) {this->EA[t]=this->PE[t];} //commented out 22-12-2011
    //else{this->EA[t]=this->PE[t]*SMi/(LP/100*FC);} //commented out 22-12-2011
    this->EA[t] = min<float>(evap1, evap2);//22-12-2011

    SMdef = FC - SMi;//Water Balance
    dUZ = max<float>((this->INSOIL[t] - SMdef - this->EA[t]), this->INSOIL[t] * pow((SMi / FC), BETA));
    dSM = this->INSOIL[t] - dUZ;
    this->SM[t] = SMi + dSM - this->EA[t];
    //if(this->SM[t]>FC){dUZ=dUZ+this->SM[t]-FC;this->SM[t]=FC;} //added 22-12-2011

    //UPPER ZONE
    if ((t == 0) | ((t > 0) & ((this->parallel == 1) & (this->hyear[t] > this->hyear[t - 1])))) UZi = UZ0; else UZi = this->UZ[t - 1]; //reset initital conditions for t=0 or when parallel sim & hydro year changes 2/1/2012
    this->UZ[t] = UZi + dUZ + this->GMLT[t];
    perc = (this->UZ[t] < PERC) ? this->UZ[t] : PERC;
    this->UZ[t] = this->UZ[t] - perc;
    QUZ1 = min<float>(this->UZ[t], UZ1) * KUZ1;
    QUZ2 = max<float>(this->UZ[t] - UZ1, 0) * KUZ2;
    this->UZ[t] = this->UZ[t] - (QUZ1 + QUZ2);//Update State


    //LOWER ZONE
    if ((t == 0) | ((t > 0) & ((this->parallel == 1) & (this->hyear[t] > this->hyear[t - 1]))))LZi = LZ0; else LZi = this->LZ[t - 1];//reset initital conditions for t=0 or when parallel sim & hydro year changes 2/1/2012
    this->LZ[t] = LZi + perc + (this->Pav[t] - this->PE[t]) * (this->pLKs / 100);
    this->LZ[t] = max<float>(this->LZ[t], 0);//To prevent negative LZ when all water is lost and PE>>>PrL and the other componets
    QLZ = this->LZ[t] * KLZ;
    this->LZ[t] = this->LZ[t] - QLZ;//Update State

    //QSIM
    this->Qsim[t] = ((QUZ1 + QUZ2) * (1 - this->pLKs / 100) + QLZ) * (this->Akm2 / (float)(86.4));//hard-coded daily flow m3/s with 24*3.6.//modified added the multiplier *(1-this->pLKs/100) 22-03-2011

    //Water Balance
    this->AvQsim = this->AvQsim + this->Qsim[t] / (this->DY);
    this->AvQobs = this->AvQobs + this->Qobs[t] / (this->DY);

    //Parallel Simulation RSQs
    if (this->parallel == 1) {
      if ((this->hyear[t] < this->hyear[t + 1]) | (t == this->DY - 1)) { //Compute RSQ for just completed Hydrological year or at end of simulation
        float PmObs, PNmr, PDnr;
        this->PAvQsim[iRSQ] = 0; this->PAvQobs[iRSQ] = 0;
        miniDY = t - trackt + 1;//Number of items in mini-hyr array
        float* PQobs = new float[miniDY];
        float* PQsim = new float[miniDY];
        float* PNm = new float[miniDY];
        float* PDn = new float[miniDY];

        for (int i = 0;i < miniDY;i++) {
          PQobs[i] = Qobs[i + trackt];
          PQsim[i] = Qsim[i + trackt];
          //Averages for water balance
          this->PAvQsim[iRSQ] = PAvQsim[iRSQ] + PQsim[i] / (miniDY);
          this->PAvQobs[iRSQ] = PAvQobs[iRSQ] + PQobs[i] / (miniDY);
        } //subset for period

        PmObs = avg<float>(PQobs, miniDY);
        for (int i = 0;i < miniDY;i++)
        {
          //cout<<"\ncheck****\n"<<i;
          PNm[i] = pow(PQsim[i] - PQobs[i], 2);
          PDn[i] = pow(PQobs[i] - PmObs, 2);
        }
        //cout<<"\ncheck****\n";
        PNmr = avg<float>(PNm, miniDY);
        PDnr = avg<float>(PDn, miniDY);
        this->NSeffparallel[iRSQ] = 1 - PNmr / PDnr;//Nash Sutcliffe RSQ for Hydrological year


        //RELATIVE VOLUMETRIC ERROR
        this->RVEparallel[iRSQ] = (this->PAvQobs[iRSQ] - this->PAvQsim[iRSQ]) / (this->PAvQsim[iRSQ]);
        if (this->RVEparallel[iRSQ] < 0) { this->RVEparallel[iRSQ] = (-1.0) * (this->RVEparallel[iRSQ]); } //Must be absolute value
        this->RVEparallel[iRSQ] = 1 - (this->RVEparallel[iRSQ]);

        //OBJECTIVE CRITERIA
        if (this->RSQtype == 0) { this->RSQparallel[iRSQ] = this->NSeffparallel[iRSQ]; }
        if (this->RSQtype == 1) { this->RSQparallel[iRSQ] = this->NSeffparallel[iRSQ] * this->RVEparallel[iRSQ]; }
        this->RVEparallel[iRSQ] = 1 - this->RVEparallel[iRSQ];
        if (icall == 1 ) {
          if (iRSQ == 0) {
            cout << star << "FOR EACH HYDROLOGICAL YEAR" << "\n";cout << "\n";
            cout << "HDYR" << fmt1 << "RSQ" << fmt1 << "NSeff" << fmt1 << "RVE [%]" << fmt1 << "Obs [m3/s]" << fmt1 << "Sim [m3/s]" << "\n";
            cout << lnz;
          }
          cout << this->hyrs[iRSQ] << fmt1 << this->RSQparallel[iRSQ] << fmt1 << this->NSeffparallel[iRSQ] << fmt2 << 100 * this->RVEparallel[iRSQ] << fmt2 << this->PAvQobs[iRSQ] << fmt2 << this->PAvQsim[iRSQ] << "\n";

        }

        trackt = trackt + miniDY;//step beginning to today
        iRSQ = iRSQ + 1; //step within RSQ array
      }
    }
  }//End DYs

  if (this->parallel == 1) {
    //Mean  the RSQparallels
    this->RSQ = avg<float>(this->RSQparallel, this->nhyrs);
    //cout<<this->RSQ<<"...checkRSQparallel\n";
    this->NSeff = avg<float>(this->NSeffparallel, this->nhyrs);
    this->RVE = avg<float>(this->RVEparallel, this->nhyrs);
    this->AvQsim = avg<float>(this->PAvQsim, this->nhyrs);
    this->AvQobs = avg<float>(this->PAvQobs, this->nhyrs);
    cout << "MEAN" << fmt1 << "OBJCr" << fmt1 << "NSeff" << fmt2 << "RVE[%]" << fmt2 << "AvQobs" << fmt2 << "AvQsim" << "\n";
    cout << "MEAN" << fmt1 << this->RSQ << fmt1 << this->NSeff << fmt2 << 100 * this->RVE << fmt2 << this->AvQobs << fmt2 << this->AvQsim << "\n";

  }
  else {
    //NASH-SUTCLIFFE RSQ EFF
    float mObs, Nmr, Dnr;
    float* Nm = new float[this->DY];
    float* Dn = new float[this->DY];
    mObs = avg<float>(Qobs, DY);
    for (i = 0;i < this->DY;i++)
    {
      Nm[i] = pow(this->Qsim[i] - this->Qobs[i], 2);
      Dn[i] = pow(this->Qobs[i] - mObs, 2);
    }
    Nmr = avg<float>(Nm, this->DY);
    Dnr = avg<float>(Dn, this->DY);
    this->NSeff = 1 - Nmr / Dnr;

    //RELATIVE VOLUMETRIC ERROR
    this->RVE = (this->AvQobs - this->AvQsim) / (this->AvQsim);
    if (this->RVE < 0) { this->RVE = (-1.0) * (this->RVE); } //Must be absolute value
    this->RVE = 1 - (this->RVE);

    //OBJECTIVE CRITERIA
    if (this->RSQtype == 0) { this->RSQ = this->NSeff; }
    if (this->RSQtype == 1) { this->RSQ = this->NSeff * this->RVE; }
    this->RVE = 1 - this->RVE;
    if (icall == 1||icall % 500 == 0) {
      if(icall==1) { cout << "\n"; }
      //cout << star << "COMPUTED OVER ENTIRE SERIES" << "\n";
      //cout << "\nYEAR" <<  setw(6) << "| HBV_RUNS:" << fmt1  << "RSQ" << fmt1 << "NSeff" << fmt1 << "RVE [%]" << fmt1 << "Obs [m3/s]" << fmt1 << "Sim [m3/s]" << "\n";
      //cout << lnz;
      //cout << "\nALL " << setw(6) << icall << fmt1  << this->RSQ << fmt1 << this->NSeff << fmt2 << 100 * this->RVE << fmt2 << this->AvQobs << fmt2 << this->AvQsim << "\n";
      if (icall > 0) {
        cout << "HBV_RUN:" << fmt4 << icall << fmt4 << "OBJCr:" <<fmt4 << this->RSQ << fmt4 << "NSeff:" << fmt4 << this->NSeff <<fmt4 << " RVE [%]:" << fmt4 << 100 * this->RVE << fmt4 << " Obs [m3/s]:" << fmt4 << this->AvQobs << fmt4 << " Sim [m3/s]:" << fmt4 << this->AvQsim << "\n";
      }
    }

    this->RSQ = this->RSQ;//(Serial simulation RSQ)

  }
  return(this->RSQ);////End hbvmodel
}
void hbv::foutRSQ() {
  string aname; aname = "RSQ.OUT";
  ofstream fxdfile;
  fxdfile.open(aname.c_str(), ios::out);//Open the file stream
  if (!fxdfile) { cerr << "\nUnable to open file parameter file"; }
  fxdfile << this->RSQ;
  fxdfile.close();
}
void hbv::flowresults()
{
  string aname = this->ts;
  string replacement = ".OUT";
  string findMe = ".txt";
  replaceChars(aname, findMe, replacement);
  ofstream pFile;
  pFile.open(aname.c_str(), ios::out);
  cout << lnz;
  cout << "\n" << fmt1 << "SAVING: " << aname << "\n\tTimeseries...";
  pFile << "First Day MM/DD/YYYY [day 0] : " << this->dato.c_str() << "\nJULIAN Number: " << this->JULIANS[0];//Added 2-1-2012
  pFile << lnz;//Added 2-1-2012
  //pFile<<fmt1<<"day";
  pFile << "HDYR" << fmt1 << "DATE" << fmt1 << "JULIAN" << fmt1 << "Pa" << fmt1 << "Ta" << fmt1 << "EA" << fmt1 << "Qsim" << fmt1 << "Qobs" << fmt1 << "Snow" << fmt1 << "Soilm" << fmt1 << "Uzone" << fmt1 << "Lzone" << fmt1 << "TotGRV" << fmt1 << "GMLT" << fmt1 << "INSOIL" << "\n";

  for (int i = 0;i < DY;i++) {//formatted out put
    //pFile<<fmt1<<i;
    pFile << this->hyear[i] << fmt1 << this->sdate[i] << fmt1 << this->JULIANS[i] << fmt1 << this->Pav[i] << fmt1 << this->Tav[i] << fmt1 << this->EA[i] << fmt1 << this->Qsim[i] << fmt1 << this->Qobs[i] << fmt1 << this->SNOWav[i] << fmt1 << this->SM[i] << fmt1 << this->UZ[i] << fmt1 << this->LZ[i] << fmt1 << this->SM[i] + this->UZ[i] + this->LZ[i] << fmt1 << this->GMLT[i] << fmt1 << this->INSOIL[i] << "\n";
  }
  pFile.close();
  cout << "\t" << "\tDONE\n";
}
void hbv::snowresults()
{
  cout << "\nXXX\n";
  string aname = this->ts;
  string replacement = ".snow.OUT";
  string findMe = ".txt";
  replaceChars(aname, findMe, replacement);
  ofstream pFile;
  pFile.open(aname.c_str(), ios::out);
  cout << "\n***Saving Snow Results\n";
  pFile << "\t" << setw(8) << "\t" << "zone" << "\t" << "day" << "\t" << "SNOW" << "\t" << "SN" << "\t" << "GM" << "\t" << "\n";
  //cout<<"\t"<<"\n***Snow Results\n";
  for (int j = 0;j < 10;j++) {//formatted out put
    for (int i = 0;i < DY;i++) {//formatted out put
      //cout<<"\t"<<"\n***Snow Results\n";
      pFile << "\t" << setw(8) << "\t" << j + 1 << "\t" << i + 1 << "\t" << this->SNOW[j][i] << "\t" << this->SN[j][i] << "\t" << this->GM[j][i] << "\t" << "\n";
      //cout<<"\n***Snow Results\n";
    }
  }
  pFile.close();
  cout << "\t" << "\n***Snow Results Saved\n";
}


class p_args {
public:
  string ts, par, fxd, dir, dato;
  int diFL, RSQtype, runtype, * DATO;
  int Snow2GlacierOption, Snow2GlacierJulianDay, parallel;//Added 02-12-2012 (extra arguments in args.txt)
  int manual, nopt, nopt2, maxn, kstop;
  float pcento;
  p_args();~p_args();
  void getfnames(int);
};
p_args::p_args() {};
p_args::~p_args() {};
void p_args::getfnames(int plots) {//read file names
  int i = 0;
  this->DATO = new int[3];
  ifstream inFile;
  inFile.open("ARGS.txt", ios::in);
  if (inFile.is_open()) {
    inFile >> this->dir;cout << "Dir\t" << this->dir << "\n";
    inFile >> this->ts;cout << "ts\t" << this->ts << "\n";
    inFile >> this->par;cout << "par\t" << this->par << "\n";
    inFile >> this->fxd;cout << "fxd\t" << this->fxd << "\n";
    inFile >> this->diFL; // multiple lapse
    inFile >> this->manual;//manual control of calib.
    inFile >> this->nopt;
    inFile >> this->nopt2;
    inFile >> this->maxn;
    inFile >> this->kstop;
    inFile >> this->pcento;
    inFile >> this->dato;cout << lnz << "BEGIN =\t" << this->dato << "\n";
    if (plots == 1) {	//Use with Grapher
      this->DATO = breakdotstring(dato);
      cout << this->DATO[0] << "-" << this->DATO[1] << "-" << this->DATO[2] << "\n";
      //cin.get();
    }
    inFile >> this->RSQtype;
    if (this->RSQtype == 0) { cout << "RSQ = NASH SUTCLIFFE (NSEFF)" << "\n"; }
    else { cout << "RSQ = NASH SUTCLIFFE *(1-VOLUMETRIC_ERROR)" << "\n"; }
    inFile >> this->runtype;
    if (this->runtype == 0)cout << "SIMULATING WITH GIVEN PARAMETERS\n";
    if (this->runtype == 1)cout << "PARAMETER STUDY RUN";
    if ((this->runtype != 0) & (this->runtype != 1)) { cout << "OPTIMISING RUN"; }
    cout << lnz;
    inFile >> this->Snow2GlacierOption;//Added 02-12-2012 (extra arguments in args.txt)
    cout << this->Snow2GlacierOption << "--Snow2GlacierOption\n";
    inFile >> this->Snow2GlacierJulianDay;//Added 02-12-2012 (extra arguments in args.txt)
    cout << this->Snow2GlacierJulianDay << "--Snow2GlacierJulianDay\n";
    if (this->Snow2GlacierOption == 0)cout << "Snow Storage On Julian Day[" << this->Snow2GlacierJulianDay << "] Not Converted to Glacier\n";//Added 02-12-2012 (extra arguments in args.txt)
    if (this->Snow2GlacierOption == 1)cout << "Snow Storage On Julian Day[" << this->Snow2GlacierJulianDay << "] Converted(Zeroed)\n";//Added 02-12-2012 (extra arguments in args.txt)
    cout << lnz;//Added 02-12-2012 (extra arguments in args.txt)
    inFile >> this->parallel;//Added 02-12-2012 (extra arguments in args.txt)
    //cout<<this->parallel<<"-->1=Parallel/0=Serial Simulation\n";
    if (this->parallel == 0)cout << "SERIAL HBV SIMULATIONS\n";//Added 02-12-2012 (extra arguments in args.txt)
    if (this->parallel == 1)cout << "PARALLEL HBV SIMULATIONS\nEach simulation is 1 Hydrological year\n";//Added 02-12-2012 (extra arguments in args.txt)
    cout << lnz;//Added 02-12-2012 (extra arguments in args.txt)
    inFile.close();
  }
}

class sce {
public:
  //DECLARATIONS
  string sortedf, unsortedf;//population files
  //int nopt;//number of parameters in model
  float* BESTX;
  //optimiser
  //SCEUA  & CCEA Global Declarations
  int icall, maxn;//number of times HBV is called and maximum allowed
  //int peps;//smallest parameter space allowed
  float** x, ** rn;//parameter array & random number array
  float fo;//the objective function value corresponding to the initial & optimisedparameters
  float* f;//Objective function array
  float** cx;float* fx;
  float* bound;//Lower & Upper bounds. See fripar.par
  int ngs;	//ngs-number of complexes (sub-populations);
  int npg;	//npg-number of members in a complex;
  int nps;	//nps- number of members in a simplex;
  int alpha; //The number of offspring  @ splx generates b4 it is replaced in the cplx
  int beta;	//nspl-number of evolution steps for each complex before shuffling;
  int pmin;//mings-minimum number of complexes required during the optimization process;
  int kstop; // maximum number of evolution loops before convergency;
  float pcento; // the percentage change allowed in kstop loops before convergency;
  int npt;//npt-Number of parameter sets
  int nopt, nopt2;// number of parameters  & parameters in optimisation
  int* lcs; // position in complex of a point[i] in simplex with nps members.
  float** sx, * ce;//simplex and centroid
  float* snew, fN; //New points created by CCEA-simplex evolution
  //int  track_call;
  int manual; //manual=1 to control opt process, =0 for auto
  //int choice; //control wwhether to optimise or run with existing parameters
  //string tsfile;

  sce(int, int, int, int, float);
  ~sce();
  //sce();sce(int);~sce();
  void sceua(int, hbv&);
  //void sceua(int,int,int,int,int,float,hbv &);
};
//sce functions
sce::sce(int anopt, int anopt2, int amaxn, int akstop, float apcento) {
  this->nopt = anopt;
  this->nopt2 = anopt2;
  this->maxn = amaxn;
  this->kstop = akstop;
  this->pcento = apcento;
  //d1
  //CPLX Declaration
  this->npg = 2 * this->nopt + 1;
  this->cx = new float* [this->npg]; for (int d = 0; d < this->npg; d++) { this->cx[d] = new float[this->nopt]; }//2*d cplx array npg *nopt
  this->fx = new float[this->npg];
  this->ngs = 2 * this->nopt2;
  this->npg = 2 * this->nopt2 + 1;
  this->nps = this->nopt2 + 1;
  this->alpha = 1;
  this->beta = 2 * this->nopt2 + 1;
  this->pmin = this->ngs;
  this->npt = (2 * this->nopt2 + 1) * this->ngs;
  //Population
  this->f = new float[this->npt];//objective functions for pupulation
  this->lcs = new int[this->nps];for (int i = 0;i < this->nps;i++) { this->lcs[i] = 0; }// @simplex points' locations in the complex
  //Initial Population this->x[N][n];
  this->x = new float* [this->npt]; for (int c = 0; c < this->npt; c++) { this->x[c] = new float[this->nopt]; }//array this->x[N][n]
  //SPLX Declaration
  this->sx = new float* [this->nps]; for (int d = 0; d < this->nps; d++) { this->sx[d] = new float[this->nopt]; }//array this->x[N][n]//d2
  //Used in CCEA
  this->snew = new float[this->nopt];//= new point generated from the simplex & the new  function value


};
//sce::sce(int anopt){this->nopt=anopt;};
sce::~sce() {};
void xfile(string sxf, int nopt, int npt, float** x, float* f, string* cp) {//ouput unsorted and sortedparameter population
  string replacement = "RSQ_PARAM_SETS.OUT";
  string findMe = "txt";
  replaceChars(sxf, findMe, replacement);
  fstream actf; actf.open(sxf.c_str(), ios::out);
  cout << "\n" << fmt1 << "SAVING: " << sxf.c_str() << "\n\t Last Random Population...";
  actf << "f,";
  for (int d = 0;d < nopt;d++) { if (d < nopt - 1) { actf << cp[d] << ","; } else { actf << cp[d] << "]\n"; } }
  for (int c = 0;c < npt;c++)
  {
    actf << fmt1 << f[c] << "\t";
    for (int d = 0;d < nopt;d++)
    {
      if (d < nopt - 1)
        actf << fmt1 << x[c][d] << ",";
      else actf << fmt1 << x[c][d] << "\n";
    }
  }actf.close();
  cout << fmt1 << "\tDONE";
}
void foutpar(string par, float* prm, float* bL, float* bU, float* cp) {
  string aname; aname = par;
  ofstream infile(aname.c_str(), ofstream::out);//Open the file stream
  if (!infile) { cerr << "\nUnable to open file " << aname << "\n"; }
  //Close the input stream//read parameters
  for (int i = 0;i < 33;i++) { infile << cp[i] << fmt1 << prm[i] << fmt1 << bL[i] << fmt1 << bU[i] << "\n"; }
  //PKORR,SKORR,HPKORR,TX,TS,CX,PRO,FC,BETA,LP,KUZ2,KUZ1,UZ1,PERC,GCX,Tlp,Tlo,SM0,UZ0,LZ0,hpkorr[0-10]
  infile.close();
}
//First create object hbv obj (string ts,string par,string fxd,int diFL)
void sce::sceua(int manual, hbv& obj) {
  //void sce::sceua(int manual,int nopt,int nopt2,int maxn,int kstop,float pcento,hbv & obj){

  //some in function declarations
  int  track_call;
  float* prm, * bL, * bU;prm = new float[this->nopt];bL = new float[this->nopt];bU = new float[this->nopt];string* cp;cp = new string[this->nopt];

  //get args
  for (int d = 0;d < this->nopt;d++) { cp[d] = obj.cp[d];prm[d] = obj.prm[d];bL[d] = obj.bL[d];bU[d] = obj.bU[d]; }

  cout << lnz << "Starting SCE-UA Optimiser" << "\n";
  cout << "RSQTYPE = " << fmt1 << obj.RSQtype << lnz;
  // Initialize random number generator
  srand((unsigned int)time(NULL));

  //Population
  float* bestx, * worstx, bestf, worstf;bestx = new float[this->nopt];worstx = new float[this->nopt];

  //cout<<"\nINITIAL PARAMETERS\nName\txo\tbL\tbU"<<lnz;
  //for(int d=0;d<this->nopt;d++)	{cout<<fmt1<<cp[d]<<fmt1<<prm[d]<<fmt1<<bL[d]<<fmt1<<bU[d]<<"\n";}

  //Bounds (bU-bL)
  this->bound = new float[this->nopt];
  for (int d = 0;d < this->nopt;d++) { this->bound[d] = bU[d] - bL[d]; }

  //Genrate Random population & Replace first set in population with existing param set
  for (int c = 0;c < this->npt;c++) {
    for (int d = 0;d < this->nopt;d++) {
      this->x[c][d] = bL[d] + ((float)rand() / RAND_MAX) * this->bound[d];
    }
  }
  for (int d = 0;d < this->nopt;d++) { this->x[0][d] = prm[d]; }//Replace values in this->x[0]d[]with xo[d]  default params

  //Calc the RSQ for each of the above population
  //fstream rout; rout.open(obj.ts +".rout.out",ios::out);
  cout << "\nRANDOM PARAMETER SETS (" << (2 * this->nopt2 + 1) * this->ngs << ")" << lnz; /*cin.get();*/
  cout << "\nGENERATING INITIAL RANDOM POPULATION\nWorking. Please Wait\n\n";
  float* xtemp;xtemp = new float[this->nopt];
  cout << "000%";for (int c = 0;c < this->npt;c++) { if ((c % (int)(this->npt / 10)) == 0) { cout << "      "; } };cout << "100%\n    ";
  //run model and return this->f[c]=RSQ
  for (int c = 0;c < this->npt;c++) {
    if ((c % (int)(this->npt / 10)) == 0) { cout << "||||||"; }

    for (int vj = 0;vj < this->nopt;vj++) { obj.prm[vj] = this->x[c][vj]; }
    this->f[c] = obj.hbvmodel(0, obj.RSQtype); //(obj.diFL);

    //rout<<"this->f["<<c<<"]"<<","<<this->f[c]<<"\t";
    //cout<<"this->f["<<c<<"]"<<","<<this->f[c]<<"\n";
    //for(int d=0;d<this->nopt;d++){if(d<this->nopt-1) rout<<this->x[c][d]<<"\t"; else rout<<this->x[c][d]<<"\n";}
  }
  //rout.close();

  //xfile(unthis->sortedf,this->nopt,this->npt,this->x,this->f,cp); //output unsorted to file
  mysort(this->f, this->npt, this->x, this->nopt);//Sort the population this->x[c][d] in order of <<decreasing>> function values this->f[c]
  //xfile(this->sortedf,this->nopt,this->npt,this->x,this->f,cp);//output sorted to file

  //Record the best and worst parameter sets of the population
  for (int d = 0;d < this->nopt;d++) { bestx[d] = this->x[0][d];worstx[d] = this->x[this->npt - 1][d]; }
  bestf = this->f[0];worstf = this->f[this->npt - 1];

  cout << star2;

  //Display status
  /*cout<<"\n\nBEST & WORST\n"; cout<<"Name\tBest\tWorst\t";
   cout<<"\nRSQ\t"<<this->f[0]<<"\t"<<this->f[this->npt-1]<<"\t"<<lnz;
   for(int d=0;d<this->nopt;d++){cout<<setw(6)<<cp[d]<<"\t"<<this->x[0][d]<<"\t"<<this->x[this->npt-1][d]<<"\n";}*/

  int igs = 0, ipg = 0, inopt = 0, k3 = 0, i = 0, j = 0, d = 0, cr = 0, h = 0, bta = 0;
  int nloop = 0; float* criter, * RVE, * Qsim,*NSEFF;
  float criter_change = 1e+5;
  float* sb, fb; sb = new float[this->nopt];//= the best point of the simplex & the best function value
  float fw, * sw; sw = new float[this->nopt];//= the worst point of the simplex & the worst function value
  float* w2, fw2; w2 = new float[this->nopt];// = the second worst point of the simplex & the second worst function value
  float* Dx; Dx = new float[this->nopt];this->ce = new float[this->nopt];
  float mysum = 0;
  int stopp;
  int lposn;//Used in the computation of k3>1//position in complex
  float critav = 0;

  //check for convergency
  if (this->icall >= this->maxn) { cout << star << "HBV runs = " << this->icall << " Exceeded Allowed " << this->maxn << "\n" << star;goto fin; }//End program

  //Begin Evolution steps
  //criter will have RSQ for @ loop while RVEcrit will have RVE
  //int nloop = 0; float* criter, * RVE, * Qsim;
  //use of kstop can potentially bring problems so i have used 10*kstop
  //it also looks like c++ is resizing the array dynamically ?
  criter = new float[10*this->kstop]; RVE = new float[10*this->kstop];Qsim = new float[10*this->kstop];critav = 0;NSEFF = new float[10*this->kstop];
  for (int tz = 0;tz < 10*this->kstop;tz++) { criter[tz] = 0;RVE[tz] = 0;Qsim[tz] = 0;NSEFF[tz] = 0; }
  //float criter_change = 1e+5;


  //for each complex create a vector of positions in this->x
  int* thiscxpos;thiscxpos = new int[this->npg]; //empty for now. Filled in @ cplx

  //d2
  //Simplex RSQ fs
  float* fs; fs = new float[this->nps];//d2

  //d3 //used to sort complex
  float** tempcx; tempcx = new float* [this->npg]; for (int i = 0;i < this->npg;i++) { tempcx[i] = new float[this->nopt]; }//d3
  float* tempfx; tempfx = new float[this->npg];//d3

  //int lposn;//Used in the computation of k3>1//position in complex
  //used in CCEA
  //float* sb, fb; sb = new float[this->nopt];//= the best point of the simplex & the best function value
  //float fw, * sw; sw = new float[this->nopt];//= the worst point of the simplex & the worst function value
  //float* w2, fw2; w2 = new float[this->nopt];// = the second worst point of the simplex & the second worst function value
  //float* Dx; Dx = new float[this->nopt];this->ce = new float[this->nopt];
  mysum = 0;
  //int stopp;
  int alph;
  this->icall = 1;
  igs = 0; ipg = 0; inopt = 0; k3 = 0; i = 0; j = 0; d = 0; cr = 0; h = 0; bta = 0;

  while ((this->icall < this->maxn)) //shuffle populations
  {

    if (this->manual == 1) { cout << "\nEnter O to stop or 1 to Continue:";cin >> stopp;if (stopp == 0) { goto fin; } }
    //cout << star;
    nloop = nloop + 1; //d1

    //COMPLEX ***********************************************************************************************
    for (igs = 0;igs < this->ngs;igs++)//Go through each complex
    {
      //commented out 20230912 to remove cout of complexes
      //cout << "\nLOOP:" << setw(5) << nloop << " | CPLX:" << setw(6) << igs + 1 << " | beta:" << setw(6) << this->npg << " ";

      //get the points for @ cplx igs from P
      for (ipg = 0;ipg < this->npg;ipg++) {
        thiscxpos[ipg] = (ipg * this->ngs + igs);
        //cout<<thiscxpos[ipg]<<"\n";
        this->fx[ipg] = this->f[thiscxpos[ipg]];// RSQ for point
        for (inopt = 0;inopt < this->nopt;inopt++) {
          //if(nloop>20){cout<<"\n****"<<"this->x[thiscxpos["<<ipg<<"]]["<<inopt<<"] = "<<this->x[thiscxpos[ipg]][inopt]<<"***\r";}
          this->cx[ipg][inopt] = x[thiscxpos[ipg]][inopt];
        }
      }//point
      //for(int i=0;i<this->npg;i++){for(j=0;j<this->nopt;j++){cout<<this->cx[i][j]<<"\t";};cout<<"\n";};cout<<"this->cx-1";cin.get();//check this->cx ok

      //cin.get();

      //SIMPLEX********************************************************************************************
      //Randomly select simplexes
      for (bta = 1;bta <= this->beta;bta++)
      {
        track_call = this->beta + 1 - bta;//monitor how we are progressing with simplexes
        this->lcs[0] = 0;//always include the best point in the complex
        for (k3 = 1;k3 < this->nps;k3++) {//removed 1+ since array starts at 0)
          //random this->lcs
          lposn=0;
          lposn = min(max(0, (int)floor(this->npg + 0.5 - sqrt(pow(this->npg + 0.5, 2) - (this->npg) * (this->npg + 1) * rand() / RAND_MAX))), (this->npg - 1));
          this->lcs[k3] = lposn; //else goto lposncalc;
          //cout<<this->lcs[k3]<<"\t";
        }//Locations chosen
        //cout<<"\n";

        //sort the locations i.e. re arrange this->lcs[k3] in ascending order o to this->nps-1
        Isort(this->lcs, this->nps);
        //for(int i=0;i<this->nps;i++){cout<<this->lcs[i]<<"\t";};cout<<"this->lcs";cin.get();//check this->lcs

        // Populate simplex s[k3][d] this->f[k3] for this complex by associating with this->cx[igs][k1][d]
        //d2
        for (k3 = 0;k3 < this->nps;k3++) {
          fs[k3] = this->fx[this->lcs[k3]];
          for (int d = 0;d < this->nopt;d++) { this->sx[k3][d] = this->cx[(this->lcs[k3])][d]; }
        }//simplex created



        //Create an offspring by evolving simplex
        for (alph = 1;alph <= this->alpha;alph++) {//this->alpha is number of times to evolve @ simplex

          //ccea(this->sx,fs);
          //START CCEA
          // Assign the best and worst points: points
          for (int d = 0;d < this->nopt;d++) {
            sb[d] = this->sx[0][d]; fb = fs[0];sw[d] = this->sx[this->nps - 1][d]; fw = fs[this->nps - 1];
            w2[d] = this->sx[this->nps - 2][d]; fw2 = fs[this->nps - 1];
          }
          // Compute the centroid of the simplex excluding the worst point

          for (int d = 0;d < this->nopt;d++) {
            for (int c = 0;c < this->nps;c++) { mysum = this->sx[c][d] + mysum; }	this->ce[d] = (mysum - sw[d]) / (this->nps - 1);mysum = 0;
          }
          mysum = 0;
          //for (int d=0;d<this->nopt;d++){cout<<this->ce[d]<<"\t";}cout<<"\n";//show the centroid

          // Attempt a REFLECTION point
          for (int d = 0;d < this->nopt;d++)
          {
            Dx[d] = 2 * (this->ce[d] - sw[d]);
            this->snew[d] = sw[d] + Dx[d];
            // Check if this->snew is outside the bounds://New random point
            if ((this->snew[d] > bU[d]) | (this->snew[d] < bL[d])) { this->snew[d] = bL[d] + (float(rand()) / float(RAND_MAX)) * this->bound[d]; }
          }
          //run HBV and return this->fN=RSQ
          this->icall = this->icall + 1;
          for (int vj = 0;vj < this->nopt;vj++) { obj.prm[vj] = this->snew[vj]; }
          this->fN = obj.hbvmodel(this->icall, obj.RSQtype);
          //this->fN=hbv(this->snew,this->icall,1,0,diffL);
          //cout<<setw(3)<<track_call<<"\t"<<setw(5)<<"hbv Runs\t"<<this->icall<<" fw:"<<setw(6)<<fw<<" |  fN:"<<setw(6)<<fN<<"\r";



          // If Reflection failed; now attempt a CONTRACTION point:
          if (this->fN < fw)
          {
            for (int d = 0;d < this->nopt;d++)
            {
              Dx[d] = float(0.5) * (this->ce[d] - sw[d]);	this->snew[d] = sw[d] + Dx[d];
              // Check if this->snew is outside the bounds:
              if ((this->snew[d] > bU[d]) | (this->snew[d] < bL[d])) { this->snew[d] = bL[d] + (float(rand()) / float(RAND_MAX)) * this->bound[d]; }
              //New random point
            }
            //run HBV and return fN=RSQ
            this->icall = this->icall + 1;
            for (int vj = 0;vj < this->nopt;vj++) { obj.prm[vj] = this->snew[vj]; }
            this->fN = obj.hbvmodel(this->icall, obj.RSQtype);
            //this->fN=hbv(this->snew,this->icall,1,0,diffL);
          }
          //cout<<setw(3)<<track_call<<"\t"<<setw(5)<<"hbv Runs\t"<<this->icall<<" fw:"<<setw(6)<<fw<<" |  fN:"<<setw(6)<<this->fN<<"\r";

          // Both reflection and contraction have failed, attempt a random point MUTATION;
          if (this->fN < fw)
          {
            for (int d = 0;d < this->nopt;d++)
            {
              this->snew[d] = bL[d] + ((float)rand() / RAND_MAX) * this->bound[d];//New random point
            }
            //run HBV and return this->fN=RSQ
            this->icall = this->icall + 1;
            for (int vj = 0;vj < this->nopt;vj++) { obj.prm[vj] = this->snew[vj]; }
            this->fN = obj.hbvmodel(this->icall, obj.RSQtype);


          }
          //cout<<setw(3)<<track_call<<"\t"<<setw(5)<<"hbv Runs\t"<<this->icall<<" fw:"<<setw(6)<<fw<<" |  this->fN:"<<setw(6)<<this->fN<<"\r";
          //end ccea


          //put new point this->snew & this->fN  into the postion in the complex where the worst point in simplex was got.
          //worst point location in this->cx =this->lcs[this->nps-1]
          for (int d = 0;d < this->nopt;d++) { this->cx[this->lcs[this->nps - 1]][d] = this->snew[d]; }//cout<<this->cx[this->lcs[this->nps-1]][d]<<"\t";}cout<<"\n";cin.get();

          this->fx[this->lcs[this->nps - 1]] = this->fN;

        }//Next Offspring


      }//End simplex

      //Sort Complex this->cx by this->fx
      mysort(this->fx, this->npg, this->cx, this->nopt);//sort by this->f[N] the values in this->x[N][n]. decreasing;
      //for(int i=0;i<this->npg;i++){for(j=0;j<this->nopt;j++){cout<<this->cx[i][j]<<"\t";};cout<<"\n";};cout<<"this->cx-1";cin.get();//check this->cx
      //Record the best and worst parameter sets in complex
      for (int d = 0;d < this->nopt;d++) { bestx[d] = this->cx[0][d];worstx[d] = this->cx[this->npg - 1][d]; }
      bestf = this->fx[0];worstf = this->fx[this->npg - 1];
      //Display status
      //for(int d=0;d<this->nopt;d++){cout<<setw(6)<<cp[d]<<"\t"<<this->cx[0][d]<<"\t"<<this->cx[this->npg-1][d]<<"\n";}

      //Run bestx
      for (int d = 0;d < this->nopt;d++) { obj.prm[d] = bestx[d]; }
      //commented out 20230912 to remove cout of complexes
      //cout << setw(5) << "| HBV_RUNS:" << setw(6) << this->icall << "| fW:" << fixed << setw(9) << setprecision(3) << worstf << "| fB:" << setw(9) << setprecision(3) << bestf << "\r";

      //for(int i=0;i<this->npg;i++){for(j=0;j<this->nopt;j++){cout<<this->cx[i][j]<<"\t";};cout<<"\n";};//cin.get();//TEst CX

      //Put Cx & this->fx back into X & this->f
      for (int i = 0;i < this->npg;i++) {
        this->f[thiscxpos[i]] = this->fx[i];
        for (j = 0;j < this->nopt;j++) {
          this->x[thiscxpos[i]][j] = this->cx[i][j];
        };
      };//cin.get();
      //for(int i=0;i<this->npg;i++){for(j=0;j<this->nopt;j++){cout<<this->x[thiscxpos[i]][j]<<"\t";};cout<<"\n";};cin.get();//cin.get();//text X

    }//End Complex

    //Sort the Population again
    //Sort the population this->x[c][d] in order of increasing function values this->f[c]
    //xfile(unthis->sortedf);
    mysort(this->f, this->npt, this->x, this->nopt);//sort by this->f[N] the values in this->x[N][n]. decreasing;
    //xfile(this->sortedf);

    //Record the best and worst parameter sets
    for (int d = 0;d < this->nopt;d++) { bestx[d] = this->x[0][d];worstx[d] = this->x[this->npt - 1][d]; }
    bestf = this->f[0];worstf = this->f[this->npt - 1];

    //Display status
    //cout<<lnz<<"\nPOPULATION BEST & WORST\n"; /*cin.get();*/
    //cout<<"Name\tBest\tWorst\t";
    //cout<<"\nRSQ\t"<<this->f[0]<<"\t"<<this->f[this->npt-1]<<"\t"<<lnz;
    for (int d = 0;d < this->nopt;d++) { obj.prm[d] = this->x[0][d]; }
    obj.hbvmodel(0, obj.RSQtype);// Run hbv for best
    //cout << lnz;modified 2023.09.12 to reduce double couting of ---
    //check for convergency
    if (this->icall >= this->maxn) { cout << star << "HBV runs = " << this->icall << " EXCEEDED " << this->maxn << "\n" << star;goto fin; }
    criter[nloop - 1] = bestf;
    RVE[nloop - 1] = obj.RVE * 100;
    Qsim[nloop - 1] = obj.AvQsim;
    NSEFF[nloop - 1] = obj.NSeff;//20230912
    /*cout << "nloop  = " << nloop << " kstop = " << this->kstop;		cout << " NSEFF[21] = " << NSEFF[21] << "\n"; */

    //modified 2023.09.12 to reduce double couting of LOOPS
    //for (cr = 0;cr < nloop;cr++) {
    //modified 2023.09.12 to add HBV runs to cout
    //cout << "\nLOOP:" << setw(5) << cr + 1 << setw(5) << "| HBV_RUNS:" << setw(6) << this->icall << " | RSQ = ";
    //cout << setw(4) << setprecision(3) << criter[cr] << " | NSE = " << setw(4) << setprecision(3) << NSEFF[cr];
    //cout << " | VE: " << setw(5) << setprecision(2) << RVE[cr] << "[%]" << " | Qobs: " << setw(5) << setprecision(2) << obj.AvQobs;
    //cout << "[m3/s]" << " | Qsim: " << setw(5) << setprecision(2) << Qsim[cr] << "[m3/s]";/*cin.get();*/
    //}
    //check if criter is being populated

    if ((cr + 1) == 1) { cout << "\n"; }
    cout << lnz;
    cout << "LOOP:" << setw(5) << cr + 1 << setw(5) << "| HBV_RUNS:" << setw(6) << this->icall << " | RSQ = ";
    cout << setw(4) << setprecision(3) << criter[cr] << " | NSE = " << setw(4) << setprecision(3) << NSEFF[cr];
    cout << " | RVE[%]: " << setw(5) << setprecision(2) << RVE[cr] << "[%]" << " | Qobs: " << setw(5) << setprecision(2) << obj.AvQobs;
    cout << "[m3/s]" << " | Qsim: " << setw(5) << setprecision(2) << Qsim[cr] << "[m3/s]\n";/*cin.get();*/
    cout << lnz2;
    cr = cr + 1;

    if (nloop >= this->kstop) {
      criter_change = abs(criter[nloop - 1] - criter[nloop - this->kstop]);//*100;
      int fst = nloop - this->kstop;	int lst = nloop - 1;critav = 0;
      for (h = fst;h <= lst;h++) { critav = abs(criter[h]) + critav; }critav = critav / (lst - fst + 1);
      criter_change = criter_change / critav;
      if (criter_change < this->pcento) {
        cout << star << "In the last " << this->kstop << " Loops, \nbestf has improved by ";
        cout << " < PCENTO (" << fixed << setprecision(5) << this->pcento << ")\nConvergency achieved based on RSQ\n" << star;
        //cin.get();
        goto fin;
      }
    }



  }//End while based on convergence or other criteria

  cout << star << "SEARCH WAS STOPPED AT TRIAL NUMBER: " << this->icall << "\n";
  cout << criter_change << "%\n" << star;

  fin:
    //cout<<"I jumped";

    for (int vj = 0;vj < this->nopt;vj++) { obj.prm[vj] = bestx[vj]; }
    this->fN = obj.hbvmodel(1, obj.RSQtype);
  cout << "\nThe best Parameter set with OBJcr = " << this->fN << "\n" << lnz;
  cout << lnz << fmt1 << "Name" << ":" << fmt1 << "PARAMETER" << fmt1 << "LOWER" << fmt1 << "UPPER" << fmt1 << "FLAG" << "\n";
  for (int i = 0;i < this->nopt;i++) {
    //cout<<"\n"<<fmt1<<cp[i]<<fmt1<<"\t"<<bestx[i]<<fmt1<<"\t"<<bL[i]<<fmt1<<"\t"<<bU[i]<<"\n";
    cout << fmt1 << obj.cp[i] << ":" << fmt1 << obj.prm[i] << fmt1 << obj.bL[i] << fmt1 << obj.bU[i] << fmt1 << obj.FLG[i] << "\n";
  }//print to screen

  //cout<<"Saving Final Parameters to file\n";
  obj.foutpar();
  //cout<<"ENTER\n";cin.get();
  //cout<<"Saving Final Snow Results to file\n";
  //obj.snowresults();
  //cout<<"ENTER\n";cin.get();
  //cout<<"Saving Final Flow Results to file\n";
  obj.flowresults();
  //cout<<"ENTER\n";cin.get();
  xfile(obj.par, this->nopt, this->npt, this->x, this->f, cp);//the full set


}//End SCEUA (){//
